"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireRole = exports.authenticateToken = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const constants_1 = require("../utils/constants");
const JWT_SECRET = process.env.JWT_SECRET || 'ems_secure_jwt_key';
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) {
        return res.status(constants_1.HTTP_STATUS.UNAUTHORIZED).json({ error: constants_1.MESSAGES.ERROR.TOKEN_MISSING });
    }
    jsonwebtoken_1.default.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(constants_1.HTTP_STATUS.FORBIDDEN).json({ error: constants_1.MESSAGES.ERROR.TOKEN_INVALID });
        }
        req.user = decoded;
        next();
    });
};
exports.authenticateToken = authenticateToken;
const requireRole = (roles) => {
    return (req, res, next) => {
        if (!req.user || !roles.includes(req.user.role)) {
            return res.status(constants_1.HTTP_STATUS.FORBIDDEN).json({ error: constants_1.MESSAGES.ERROR.UNAUTHORIZED_ROLE });
        }
        next();
    };
};
exports.requireRole = requireRole;
//# sourceMappingURL=auth.middleware.js.map