export {};
//# sourceMappingURL=fix-exams.d.ts.map