"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongodb_1 = require("mongodb");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config({ path: `.${process.env.N_ENV}.env` });
const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/ems';
const client = new mongodb_1.MongoClient(uri);
async function fix() {
    try {
        await client.connect();
        const db = client.db();
        const activeYear = await db.collection('academic_years').findOne({ isActive: true });
        if (!activeYear) {
            console.log("No active academic year found.");
            return;
        }
        const result = await db.collection('exams').updateMany({ academicYearId: { $exists: false } }, { $set: { academicYearId: activeYear._id } });
        console.log(`Fixed ${result.modifiedCount} exams by attaching them to ${activeYear.name}.`);
    }
    catch (e) {
        console.error("Error", e);
    }
    finally {
        await client.close();
    }
}
fix();
//# sourceMappingURL=fix-exams.js.map