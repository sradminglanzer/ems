"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeeGroup = void 0;
const mongodb_1 = require("mongodb");
class FeeGroup {
    _id;
    entityId;
    name;
    description;
    yearlyRosters;
    members = []; // For non-academic tenants like Gyms
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityId = new mongodb_1.ObjectId(data.entityId);
        this.name = data.name;
        this.description = data.description;
        // Handle migration from old 'members' array or newly constructed 'yearlyRosters'
        this.yearlyRosters = [];
        if (Array.isArray(data.yearlyRosters)) {
            this.yearlyRosters = data.yearlyRosters.map((r) => ({
                academicYearId: new mongodb_1.ObjectId(r.academicYearId),
                members: Array.isArray(r.members) ? r.members.map((id) => new mongodb_1.ObjectId(id)) : []
            }));
        }
        else if (Array.isArray(data.members)) {
            // Legacy/Direct Mapping for non-academic tenants
            this.members = data.members.map((id) => new mongodb_1.ObjectId(id));
        }
        else {
            this.members = [];
        }
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
    get valid() {
        return !!(this.entityId && this.name);
    }
}
exports.FeeGroup = FeeGroup;
//# sourceMappingURL=fee-group.model.js.map