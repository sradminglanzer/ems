import { ObjectId } from 'mongodb';
export declare class FeePayment {
    _id?: ObjectId;
    entityId: ObjectId;
    memberId: ObjectId;
    academicYearId?: ObjectId;
    feeGroupId?: ObjectId;
    feeStructureId?: ObjectId;
    amount: number;
    notes?: string;
    paymentMethod?: string;
    referenceDocumentUrl?: string;
    receiptNo?: string;
    paymentDate: Date;
    nextPaymentDate?: Date;
    createdAt?: Date;
    updatedAt?: Date;
    constructor(data: any);
    get valid(): boolean;
}
//# sourceMappingURL=fee-payment.model.d.ts.map