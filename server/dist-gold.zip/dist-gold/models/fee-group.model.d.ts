import { ObjectId } from 'mongodb';
export interface YearlyRoster {
    academicYearId: ObjectId;
    members: ObjectId[];
}
export declare class FeeGroup {
    _id?: ObjectId;
    entityId: ObjectId;
    name: string;
    description?: string;
    yearlyRosters: YearlyRoster[];
    members: ObjectId[];
    createdAt?: Date;
    updatedAt?: Date;
    constructor(data: any);
    get valid(): boolean;
}
//# sourceMappingURL=fee-group.model.d.ts.map