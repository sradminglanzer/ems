"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EXPENSE_CATEGORIES = void 0;
exports.EXPENSE_CATEGORIES = [
    'Rent / Lease',
    'Electricity',
    'Water',
    'Internet & Phone',
    'Staff Salaries',
    'Equipment Purchase',
    'Equipment Maintenance',
    'Cleaning & Housekeeping',
    'Marketing & Advertising',
    'Supplements & Products',
    'Gym Supplies',
    'Software & Subscriptions',
    'Insurance',
    'Taxes & Govt Fees',
    'Miscellaneous',
];
//# sourceMappingURL=expense.model.js.map