import { BaseService } from './base.service';
import { User } from '../models/types';
import { ObjectId } from 'mongodb';
declare class AuthService extends BaseService<User> {
    constructor();
    handleLoginOrSetup(contactNumber: string, entityId?: string, mpin?: string): Promise<{
        requiresEntitySelection: boolean;
        entities: {
            id: any;
            name: any;
            logoUrl: any;
            type: any;
        }[];
        requiresSetup?: never;
        message?: never;
        entity?: never;
        token?: never;
        user?: never;
        requiresMpin?: never;
    } | {
        requiresSetup: boolean;
        message: "MPIN setup required";
        entity: {
            id: any;
            name: string;
            logoUrl: string | undefined;
        };
        requiresEntitySelection?: never;
        entities?: never;
        token?: never;
        user?: never;
        requiresMpin?: never;
    } | {
        message: "MPIN setup successful";
        token: string;
        user: {
            id: ObjectId | undefined;
            entityId: ObjectId;
            entityName: string | undefined;
            entityType: string | undefined;
            entityLogoUrl: string | undefined;
            name: string;
            role: import("../models/types").UserRole;
            contactNumber: string;
            activeAcademicYearId: any;
            activeAcademicYearName: any;
        };
        requiresEntitySelection?: never;
        entities?: never;
        requiresSetup?: never;
        entity?: never;
        requiresMpin?: never;
    } | {
        requiresMpin: boolean;
        message: string;
        entity: {
            id: any;
            name: string;
            logoUrl: string | undefined;
        };
        requiresEntitySelection?: never;
        entities?: never;
        requiresSetup?: never;
        token?: never;
        user?: never;
    } | {
        message: "Login successful";
        token: string;
        user: {
            id: ObjectId | undefined;
            entityId: ObjectId;
            entityName: string | undefined;
            entityType: string | undefined;
            entityLogoUrl: string | undefined;
            name: string;
            role: import("../models/types").UserRole;
            contactNumber: string;
            activeAcademicYearId: any;
            activeAcademicYearName: any;
        };
        requiresEntitySelection?: never;
        entities?: never;
        requiresSetup?: never;
        entity?: never;
        requiresMpin?: never;
    }>;
    private generateToken;
    private formatUserResponse;
}
declare const _default: AuthService;
export default _default;
//# sourceMappingURL=auth.service.d.ts.map