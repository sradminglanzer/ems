import { BaseService } from './base.service';
import { ISubject } from '../models/subject.model';
declare class SubjectService extends BaseService<ISubject> {
    constructor();
}
declare const _default: SubjectService;
export default _default;
//# sourceMappingURL=subject.service.d.ts.map