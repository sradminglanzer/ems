"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
class SubjectService extends base_service_1.BaseService {
    constructor() {
        super('subjects');
    }
}
exports.default = new SubjectService();
//# sourceMappingURL=subject.service.js.map