import { BaseService } from './base.service';
import { IDiary } from '../models/diary.model';
declare class DiaryService extends BaseService<IDiary> {
    constructor();
    getDiariesPopulated(filter: any): Promise<import("bson").Document[]>;
}
declare const _default: DiaryService;
export default _default;
//# sourceMappingURL=diary.service.d.ts.map