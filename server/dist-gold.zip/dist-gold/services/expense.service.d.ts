import { BaseService } from './base.service';
import { IExpense, RecurringFrequency } from '../models/expense.model';
export declare function computeNextRecurringDate(from: Date, frequency: RecurringFrequency): Date;
declare class ExpenseService extends BaseService<IExpense> {
    constructor();
    getFilteredExpenses(entityId: string, opts?: {
        startDate?: Date;
        endDate?: Date;
        category?: string;
        paymentMethod?: string;
    }): Promise<import("bson").Document[]>;
    /** Summary: total per category for a given month */
    getMonthlySummary(entityId: string, year: number, month: number): Promise<import("bson").Document[]>;
}
declare const _default: ExpenseService;
export default _default;
//# sourceMappingURL=expense.service.d.ts.map