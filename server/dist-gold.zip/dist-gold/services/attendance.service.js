"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
class AttendanceService extends base_service_1.BaseService {
    constructor() {
        super('attendances');
    }
    async getAttendanceWithMembers(filter) {
        const results = await this.getCollection().aggregate([
            { $match: filter },
            {
                $lookup: {
                    from: 'members',
                    localField: 'records.memberId',
                    foreignField: '_id',
                    as: 'populatedMembers'
                }
            }
        ]).toArray();
        if (!results || results.length === 0)
            return null;
        const doc = results[0];
        if (!doc)
            return null;
        // Map the populated members back into the records array
        const memberMap = new Map(doc.populatedMembers.map((m) => [m._id.toString(), m]));
        doc.records = doc.records.map((r) => ({
            ...r,
            memberId: memberMap.get(r.memberId.toString()) || r.memberId
        }));
        delete doc.populatedMembers;
        return doc;
    }
}
exports.default = new AttendanceService();
//# sourceMappingURL=attendance.service.js.map