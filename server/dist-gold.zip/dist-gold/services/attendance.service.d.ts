import { BaseService } from './base.service';
import { IAttendance } from '../models/attendance.model';
declare class AttendanceService extends BaseService<IAttendance> {
    constructor();
    getAttendanceWithMembers(filter: any): Promise<import("bson").Document | null>;
}
declare const _default: AttendanceService;
export default _default;
//# sourceMappingURL=attendance.service.d.ts.map