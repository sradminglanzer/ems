"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
const mongodb_1 = require("mongodb");
class FeePaymentService extends base_service_1.BaseService {
    constructor() {
        super('fee_payments');
    }
    async getByEntity(entityId, academicYearId, customFilter = {}) {
        const query = { entityId: new mongodb_1.ObjectId(entityId), ...customFilter };
        if (academicYearId) {
            query.academicYearId = new mongodb_1.ObjectId(academicYearId);
        }
        return this.get(query);
    }
    async getByMember(memberId, entityId, academicYearId) {
        const query = { memberId: new mongodb_1.ObjectId(memberId), entityId: new mongodb_1.ObjectId(entityId) };
        if (academicYearId) {
            query.academicYearId = new mongodb_1.ObjectId(academicYearId);
        }
        return this.get(query, { sort: { paymentDate: -1 } });
    }
    async getNextSequence(entityId) {
        const { getDB } = require('../config/db');
        const db = getDB();
        const counters = db.collection('counters');
        const result = await counters.findOneAndUpdate({ _id: `receiptNo_${entityId.toString()}` }, { $inc: { seq: 1 } }, { returnDocument: 'after', upsert: true });
        const seqNum = result?.seq || 1;
        const paddedSeq = String(seqNum).padStart(4, '0');
        return `REC-${paddedSeq}`;
    }
    async setNextSequence(entityId, newSeq) {
        const { getDB } = require('../config/db');
        const db = getDB();
        const counters = db.collection('counters');
        await counters.updateOne({ _id: `receiptNo_${entityId.toString()}` }, { $set: { seq: newSeq - 1 } }, { upsert: true });
        return true;
    }
}
exports.default = new FeePaymentService();
//# sourceMappingURL=fee-payment.service.js.map