"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
class DiaryService extends base_service_1.BaseService {
    constructor() {
        super('diaries');
    }
    async getDiariesPopulated(filter) {
        return await this.getCollection().aggregate([
            { $match: filter },
            { $sort: { createdAt: -1 } },
            {
                $lookup: {
                    from: 'subjects',
                    localField: 'subjectId',
                    foreignField: '_id',
                    as: 'subjectId'
                }
            },
            { $unwind: { path: '$subjectId', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'users',
                    localField: 'createdBy',
                    foreignField: '_id',
                    as: 'createdBy'
                }
            },
            { $unwind: { path: '$createdBy', preserveNullAndEmptyArrays: true } },
            {
                $lookup: {
                    from: 'members',
                    localField: 'studentTracking.memberId',
                    foreignField: '_id',
                    as: 'populatedMembers'
                }
            },
            {
                $project: {
                    'createdBy.password': 0,
                    'createdBy.mPin': 0
                }
            }
        ]).toArray();
    }
}
exports.default = new DiaryService();
//# sourceMappingURL=diary.service.js.map