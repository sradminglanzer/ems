import { Request, Response, NextFunction } from 'express';
export declare const getExpenses: (req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const getCategories: (_req: Request, res: Response, next: NextFunction) => Promise<void>;
export declare const createExpense: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateExpense: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const deleteExpense: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const confirmRecurring: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=expense.controller.d.ts.map