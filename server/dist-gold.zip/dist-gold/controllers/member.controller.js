"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resumeMember = exports.holdMember = exports.deleteMember = exports.updateMember = exports.createMember = exports.getMemberById = exports.getMembers = void 0;
const member_service_1 = __importDefault(require("../services/member.service"));
const member_model_1 = require("../models/member.model");
const user_model_1 = require("../models/user.model");
const fee_payment_model_1 = require("../models/fee-payment.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const mongodb_1 = require("mongodb");
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const fee_structure_service_1 = __importDefault(require("../services/fee-structure.service"));
const fee_payment_service_1 = __importDefault(require("../services/fee-payment.service"));
const user_service_1 = __importDefault(require("../services/user.service"));
const getMembers = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        let members = await member_service_1.default.getByEntity(entityId);
        if (req.user.role === 'parent') {
            const parentUser = await user_service_1.default.getOne({ _id: new mongodb_1.ObjectId(req.user.userId) });
            if (parentUser && parentUser.contactNumber) {
                members = members.filter(m => m.contact === parentUser.contactNumber || m.altContact === parentUser.contactNumber);
            }
            else {
                members = [];
            }
        }
        const [feeGroups, feeStructures, feePayments] = await Promise.all([
            fee_group_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId)
        ]);
        const academicYearIdStr = req.query.academicYearId;
        // Calculate total structural fees per group
        const groupTotalFees = {};
        feeGroups.forEach(g => {
            const groupStructures = feeStructures.filter(s => s.feeGroupId && s.feeGroupId.toString() === g._id.toString());
            const totalFee = groupStructures.reduce((sum, s) => sum + s.amount, 0);
            groupTotalFees[g._id.toString()] = totalFee;
        });
        // Enrich members with group and fee stats
        const memberStats = members.map(m => {
            const mId = m._id.toString();
            // find group based on the requested academic year
            let group;
            if (academicYearIdStr) {
                group = feeGroups.find(g => {
                    const roster = g.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearIdStr);
                    return roster && roster.members && roster.members.some((id) => id.toString() === mId);
                });
            }
            else {
                // Fallback if no year passed: check generic members array then rosters 
                group = feeGroups.find(g => {
                    return (g.members && g.members.some((id) => id.toString() === mId)) ||
                        (g.yearlyRosters?.some((r) => r.members && r.members.some((id) => id.toString() === mId)));
                });
            }
            let totalFee = 0;
            let groupName = 'Unassigned';
            if (group) {
                totalFee = groupTotalFees[group._id.toString()] || 0;
                groupName = group.name;
            }
            let addonNames = [];
            if (m.addonFeeIds && m.addonFeeIds.length > 0) {
                const addons = feeStructures.filter(s => m.addonFeeIds.some((id) => id.toString() === s._id.toString()));
                totalFee += addons.reduce((sum, s) => sum + s.amount, 0);
                addonNames = addons.map(s => s.name);
            }
            // find payments
            const memberPayments = feePayments.filter(p => p.memberId.toString() === mId);
            const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0);
            return {
                ...m,
                groupName,
                addonNames,
                totalFee,
                totalPaid,
                pendingAmount: totalFee - totalPaid
            };
        });
        res.status(constants_1.HTTP_STATUS.OK).json(memberStats);
    }
    catch (error) {
        next(error);
    }
};
exports.getMembers = getMembers;
const getMemberById = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const id = req.params.id;
        const academicYearIdStr = req.query.academicYearId;
        const m = await member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) });
        if (!m) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Member not found' });
        }
        const [feeGroups, feeStructures, feePayments] = await Promise.all([
            fee_group_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId)
        ]);
        const groupTotalFees = {};
        feeGroups.forEach(g => {
            const groupStructures = feeStructures.filter(s => s.feeGroupId && s.feeGroupId.toString() === g._id.toString());
            const totalFee = groupStructures.reduce((sum, s) => sum + s.amount, 0);
            groupTotalFees[g._id.toString()] = totalFee;
        });
        const mId = m._id.toString();
        let group;
        if (academicYearIdStr) {
            group = feeGroups.find(g => {
                const roster = g.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearIdStr);
                return roster && roster.members && roster.members.some((id) => id.toString() === mId);
            });
        }
        else {
            group = feeGroups.find(g => {
                return (g.members && g.members.some((id) => id.toString() === mId)) ||
                    (g.yearlyRosters?.some((r) => r.members && r.members.some((id) => id.toString() === mId)));
            });
        }
        let totalFee = 0;
        let groupName = 'Unassigned';
        if (group) {
            totalFee = groupTotalFees[group._id.toString()] || 0;
            groupName = group.name;
        }
        let addonNames = [];
        if (m.addonFeeIds && m.addonFeeIds.length > 0) {
            const addons = feeStructures.filter(s => m.addonFeeIds.some((id) => id.toString() === s._id.toString()));
            totalFee += addons.reduce((sum, s) => sum + s.amount, 0);
            addonNames = addons.map(s => s.name);
        }
        const memberPayments = feePayments.filter(p => p.memberId.toString() === mId);
        const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0);
        const memberStats = {
            ...m,
            groupName,
            addonNames,
            totalFee,
            totalPaid,
            pendingAmount: totalFee - totalPaid
        };
        res.status(constants_1.HTTP_STATUS.OK).json(memberStats);
    }
    catch (error) {
        next(error);
    }
};
exports.getMemberById = getMemberById;
const createMember = async (req, res, next) => {
    try {
        const member = new member_model_1.Member({ ...req.body, entityId: req.user.entityId });
        if (!member.valid) {
            throw new AppError_1.AppError('Invalid member data. First Name, Last Name and Known ID are required.', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await member_service_1.default.insert(member);
        // Auto-assign to fee group if requested inline
        if (req.body.feeGroupId) {
            try {
                const groupId = new mongodb_1.ObjectId(req.body.feeGroupId);
                const memberIdObj = new mongodb_1.ObjectId(result.insertedId.toString());
                // Fetch group
                const group = await fee_group_service_1.default.getOne({ _id: groupId, entityId: new mongodb_1.ObjectId(req.user.entityId) });
                if (group) {
                    if (req.body.academicYearId) {
                        // School: store in yearlyRosters
                        const yearId = new mongodb_1.ObjectId(req.body.academicYearId);
                        let rosters = group.yearlyRosters || [];
                        const rosterIdx = rosters.findIndex((r) => r.academicYearId.toString() === yearId.toString());
                        if (rosterIdx > -1) {
                            let currentMembers = rosters[rosterIdx].members || [];
                            const exists = currentMembers.some((m) => m.toString() === memberIdObj.toString());
                            if (!exists) {
                                currentMembers.push(memberIdObj);
                            }
                            rosters[rosterIdx].members = currentMembers;
                        }
                        else {
                            rosters.push({
                                academicYearId: yearId,
                                members: [memberIdObj]
                            });
                        }
                        await fee_group_service_1.default.update({ _id: groupId, entityId: new mongodb_1.ObjectId(req.user.entityId) }, { $set: { yearlyRosters: rosters } });
                        // Also store feeGroupId on the member for fast lookup
                        await member_service_1.default.update({ _id: memberIdObj }, { $set: { feeGroupId: groupId } });
                    }
                    else {
                        // Gym: store in feeGroup.members[] AND on member.feeGroupId
                        let directMembers = group.members || [];
                        const exists = directMembers.some((m) => m.toString() === memberIdObj.toString());
                        if (!exists) {
                            directMembers.push(memberIdObj);
                            await fee_group_service_1.default.update({ _id: groupId, entityId: new mongodb_1.ObjectId(req.user.entityId) }, { $set: { members: directMembers } });
                        }
                        // Always write feeGroupId back to the member for fast lookup
                        await member_service_1.default.update({ _id: memberIdObj }, { $set: { feeGroupId: groupId } });
                    }
                }
            }
            catch (e) {
                console.error('Error auto-enrolling into fee group during member creation:', e);
            }
        }
        // Ensure a parent user exists for this contact number
        try {
            if (member.contact) {
                const existingParent = await user_service_1.default.getOne({
                    entityId: new mongodb_1.ObjectId(req.user.entityId),
                    contactNumber: member.contact
                });
                if (!existingParent) {
                    const newUser = new user_model_1.User({
                        entityId: new mongodb_1.ObjectId(req.user.entityId),
                        name: `Parent of ${member.firstName}`,
                        contactNumber: member.contact,
                        role: 'parent',
                        mpin: '' // Require setup
                    });
                    await user_service_1.default.insert(newUser);
                }
            }
        }
        catch (e) {
            console.error('Error auto-creating parent user:', e);
        }
        let generatedReceiptNo;
        // POS Onboarding: Inject Fee Payment
        if (req.body.initialPayment) {
            try {
                const { amount, paymentMethod, nextPaymentDateStr, referenceDocumentUrl } = req.body.initialPayment;
                const payment = new fee_payment_model_1.FeePayment({
                    entityId: new mongodb_1.ObjectId(req.user.entityId),
                    memberId: new mongodb_1.ObjectId(result.insertedId.toString()),
                    amount: amount,
                    paymentMethod: paymentMethod || 'cash',
                    referenceDocumentUrl: referenceDocumentUrl,
                    paymentDate: new Date(), // Today
                    nextPaymentDate: nextPaymentDateStr ? new Date(nextPaymentDateStr) : undefined,
                    notes: 'POS Initial Onboarding Payment'
                });
                if (payment.valid) {
                    payment.receiptNo = await fee_payment_service_1.default.getNextSequence(req.user.entityId);
                    generatedReceiptNo = payment.receiptNo;
                    await fee_payment_service_1.default.insert(payment);
                }
                else {
                    console.error('Initial payment payload invalid:', payment);
                }
            }
            catch (e) {
                console.error('Error recording POS initial payment:', e);
            }
        }
        res.status(constants_1.HTTP_STATUS.CREATED).json({ insertedId: result.insertedId, receiptNo: generatedReceiptNo });
    }
    catch (error) {
        next(error);
    }
};
exports.createMember = createMember;
const updateMember = async (req, res, next) => {
    try {
        const id = req.params.id;
        if (req.body.entityId)
            delete req.body.entityId;
        // Validation for partial update
        let updateData = { $set: {} };
        const allowedFields = ['firstName', 'middleName', 'lastName', 'knownId', 'dob', 'contact', 'altContact', 'fatherOccupation', 'motherOccupation', 'address', 'addonFeeIds', 'profilePicUrl'];
        allowedFields.forEach(field => {
            if (req.body[field] !== undefined) {
                updateData.$set[field] = req.body[field];
            }
        });
        if (Object.keys(updateData.$set).length === 0) {
            delete updateData.$set;
        }
        const result = await member_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(req.user.entityId) }, updateData);
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true });
    }
    catch (error) {
        next(error);
    }
};
exports.updateMember = updateMember;
const deleteMember = async (req, res, next) => {
    try {
        const id = req.params.id;
        const result = await member_service_1.default.delete({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(req.user.entityId) });
        if (result) {
            res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Member deleted' });
        }
        else {
            res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Member not found' });
        }
    }
    catch (error) {
        next(error);
    }
};
exports.deleteMember = deleteMember;
const holdMember = async (req, res, next) => {
    try {
        const id = req.params.id;
        const entityId = String(req.user.entityId);
        const member = await member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) });
        if (!member) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Member not found' });
        }
        if (member.status === 'on_hold') {
            return res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json({ message: 'Member is already on hold' });
        }
        await member_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) }, { $set: { status: 'on_hold', holdStartDate: new Date(), updatedAt: new Date() } });
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Member placed on hold' });
    }
    catch (error) {
        next(error);
    }
};
exports.holdMember = holdMember;
const resumeMember = async (req, res, next) => {
    try {
        const id = req.params.id;
        const entityId = String(req.user.entityId);
        const member = await member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) });
        if (!member) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Member not found' });
        }
        if (member.status !== 'on_hold') {
            return res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json({ message: 'Member is not on hold' });
        }
        // Build updated hold history
        const holdEntry = {
            holdDate: member.holdStartDate || new Date(),
            resumeDate: new Date()
        };
        const existingHistory = member.holdHistory || [];
        const updatedHistory = [...existingHistory, holdEntry];
        await member_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) }, {
            $set: {
                status: 'active',
                holdHistory: updatedHistory,
                updatedAt: new Date()
            },
            $unset: { holdStartDate: '' }
        });
        // Optional: record re-join payment in same call
        let generatedReceiptNo;
        if (req.body.initialPayment) {
            try {
                const { amount, paymentMethod, nextPaymentDateStr, referenceDocumentUrl } = req.body.initialPayment;
                const payment = new fee_payment_model_1.FeePayment({
                    entityId: new mongodb_1.ObjectId(entityId),
                    memberId: new mongodb_1.ObjectId(id),
                    amount,
                    paymentMethod: paymentMethod || 'cash',
                    referenceDocumentUrl,
                    paymentDate: new Date(),
                    nextPaymentDate: nextPaymentDateStr ? new Date(nextPaymentDateStr) : undefined,
                    notes: 'Re-join Payment after Hold'
                });
                if (payment.valid) {
                    payment.receiptNo = await fee_payment_service_1.default.getNextSequence(entityId);
                    generatedReceiptNo = payment.receiptNo;
                    await fee_payment_service_1.default.insert(payment);
                }
            }
            catch (e) {
                console.error('Error recording re-join payment:', e);
            }
        }
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Member resumed', receiptNo: generatedReceiptNo });
    }
    catch (error) {
        next(error);
    }
};
exports.resumeMember = resumeMember;
//# sourceMappingURL=member.controller.js.map