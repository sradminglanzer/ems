"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMemberAttendance = exports.saveAttendance = exports.getAttendance = void 0;
const attendance_service_1 = __importDefault(require("../services/attendance.service"));
const member_service_1 = __importDefault(require("../services/member.service"));
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const AppError_1 = require("../utils/AppError");
const mongodb_1 = require("mongodb");
// Normalize date to start of day UTC
const normalizeDate = (dateString) => {
    const d = new Date(dateString);
    return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0));
};
const getAttendance = async (req, res) => {
    try {
        const { entityId } = req.user;
        const { classId, date, academicYearId } = req.query;
        if (!classId || !date) {
            return res.status(400).json(new AppError_1.AppError('classId and date are required', 400));
        }
        const normalizedDate = normalizeDate(date);
        let attendance = await attendance_service_1.default.getAttendanceWithMembers({
            entityId: new mongodb_1.ObjectId(entityId),
            classId: new mongodb_1.ObjectId(classId),
            date: normalizedDate
        });
        // If attendance hasn't been marked yet for this day, generate a template
        if (!attendance) {
            const feeGroup = await fee_group_service_1.default.getOne({
                _id: new mongodb_1.ObjectId(classId),
                entityId: new mongodb_1.ObjectId(entityId)
            });
            if (!feeGroup) {
                return res.status(404).json(new AppError_1.AppError('Class not found', 404));
            }
            let memberIds = [];
            if (academicYearId) {
                const roster = feeGroup.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearId);
                if (roster && roster.members) {
                    memberIds = roster.members.map((id) => id.toString());
                }
            }
            else {
                memberIds = feeGroup.members?.map((id) => id.toString()) || [];
            }
            if (memberIds.length === 0) {
                return res.status(200).json({ isNew: true, records: [] });
            }
            const allMembers = await member_service_1.default.getByEntity(entityId);
            const classMembers = allMembers.filter(m => memberIds.includes(m._id.toString()));
            const defaultRecords = classMembers.map(m => ({
                memberId: m,
                status: 'present',
                remarks: ''
            }));
            return res.status(200).json({
                isNew: true,
                entityId,
                classId,
                date: normalizedDate,
                records: defaultRecords
            });
        }
        res.status(200).json({ isNew: false, ...attendance });
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.getAttendance = getAttendance;
const saveAttendance = async (req, res) => {
    try {
        const { entityId, userId } = req.user;
        const { classId, date, academicYearId, records } = req.body;
        if (!classId || !date || !records) {
            return res.status(400).json(new AppError_1.AppError('classId, date, and records are required', 400));
        }
        const normalizedDate = normalizeDate(date);
        const updateData = {
            recordedBy: new mongodb_1.ObjectId(userId),
            records: records.map((r) => ({
                ...r,
                memberId: new mongodb_1.ObjectId(r.memberId)
            })),
            updatedAt: new Date()
        };
        if (academicYearId)
            updateData.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const existing = await attendance_service_1.default.getOne({
            entityId: new mongodb_1.ObjectId(entityId),
            classId: new mongodb_1.ObjectId(classId),
            date: normalizedDate
        });
        if (existing) {
            await attendance_service_1.default.update({ _id: existing._id }, { $set: updateData });
        }
        else {
            await attendance_service_1.default.insert({
                entityId: new mongodb_1.ObjectId(entityId),
                classId: new mongodb_1.ObjectId(classId),
                date: normalizedDate,
                ...updateData,
                createdAt: new Date()
            });
        }
        res.status(200).json({ success: true });
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.saveAttendance = saveAttendance;
const getMemberAttendance = async (req, res) => {
    try {
        const { entityId } = req.user;
        const memberId = req.params.memberId;
        const { academicYearId } = req.query;
        const filter = {
            entityId: new mongodb_1.ObjectId(entityId),
            'records.memberId': new mongodb_1.ObjectId(memberId)
        };
        if (academicYearId) {
            filter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        }
        const attendances = await attendance_service_1.default.get(filter, { sort: { date: -1 } });
        const memberHistory = attendances.map(att => {
            const record = att.records.find((r) => r.memberId.toString() === memberId);
            return {
                date: att.date,
                status: record?.status || 'unknown',
                remarks: record?.remarks || ''
            };
        });
        res.status(200).json(memberHistory);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.getMemberAttendance = getMemberAttendance;
//# sourceMappingURL=attendance.controller.js.map