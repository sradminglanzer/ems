"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMemberReportCard = exports.getClassRankSheet = exports.addResult = exports.getMemberResults = exports.getResults = exports.createExam = exports.getExams = void 0;
const exam_service_1 = __importDefault(require("../services/exam.service"));
const exam_result_service_1 = __importDefault(require("../services/exam-result.service"));
const member_service_1 = __importDefault(require("../services/member.service"));
const exam_model_1 = require("../models/exam.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const mongodb_1 = require("mongodb");
// Indian Standard Grading
const getGrade = (percentage) => {
    if (percentage >= 90)
        return 'A+';
    if (percentage >= 75)
        return 'A';
    if (percentage >= 60)
        return 'B';
    if (percentage >= 45)
        return 'C';
    if (percentage >= 33)
        return 'D';
    return 'F';
};
const getExams = async (req, res, next) => {
    try {
        const academicYearId = req.query.academicYearId;
        const exams = await exam_service_1.default.getByEntity(req.user.entityId, academicYearId);
        res.status(constants_1.HTTP_STATUS.OK).json(exams);
    }
    catch (error) {
        next(error);
    }
};
exports.getExams = getExams;
const createExam = async (req, res, next) => {
    try {
        const exam = new exam_model_1.Exam({ ...req.body, entityId: req.user.entityId });
        if (!exam.valid) {
            throw new AppError_1.AppError('Invalid exam data. Make sure name, startDate, endDate, academicYearId, and subjects are provided.', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await exam_service_1.default.insert(exam);
        res.status(constants_1.HTTP_STATUS.CREATED).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.createExam = createExam;
const getResults = async (req, res, next) => {
    try {
        const examId = req.params.examId;
        const results = await exam_result_service_1.default.getByExam(examId);
        res.status(constants_1.HTTP_STATUS.OK).json(results);
    }
    catch (error) {
        next(error);
    }
};
exports.getResults = getResults;
const getMemberResults = async (req, res, next) => {
    try {
        const memberId = req.params.memberId;
        const results = await exam_result_service_1.default.getByMember(memberId);
        // Also fetch exam headers so frontend has the exam names
        const examIds = [...new Set(results.map(r => r.examId.toString()))];
        const exams = await exam_service_1.default.get({ _id: { $in: examIds.map(id => new mongodb_1.ObjectId(id)) } });
        const enrichedResults = results.map(r => {
            const exam = exams.find(e => e._id.toString() === r.examId.toString());
            return { ...r, examName: exam?.name };
        });
        res.status(constants_1.HTTP_STATUS.OK).json(enrichedResults);
    }
    catch (error) {
        next(error);
    }
};
exports.getMemberResults = getMemberResults;
const addResult = async (req, res, next) => {
    try {
        const examId = req.params.examId;
        const results = req.body.results;
        if (!Array.isArray(results)) {
            throw new AppError_1.AppError('Results must be an array', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await exam_result_service_1.default.saveBulk(examId, req.user.entityId, results);
        res.status(constants_1.HTTP_STATUS.CREATED).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.addResult = addResult;
// GET /exams/:examId/rank-sheet — Class Leaderboard
const getClassRankSheet = async (req, res, next) => {
    try {
        const examId = req.params.examId;
        const entityId = req.user.entityId.toString();
        const [exam, results, allMembers] = await Promise.all([
            exam_service_1.default.getOne({ _id: new mongodb_1.ObjectId(examId), entityId: new mongodb_1.ObjectId(entityId) }),
            exam_result_service_1.default.getByExam(examId),
            member_service_1.default.getByEntity(entityId)
        ]);
        if (!exam)
            throw new AppError_1.AppError('Exam not found', constants_1.HTTP_STATUS.NOT_FOUND);
        const memberMap = new Map(allMembers.map((m) => [m._id.toString(), m]));
        const ranked = results
            .map((r) => {
            const totalScore = r.marks.reduce((sum, m) => sum + m.score, 0);
            const totalMax = r.marks.reduce((sum, m) => sum + m.maxScore, 0);
            const percentage = totalMax > 0 ? Math.round((totalScore / totalMax) * 100) : 0;
            const grade = getGrade(percentage);
            const member = memberMap.get(r.memberId.toString());
            return {
                memberId: r.memberId,
                name: member ? `${member.firstName} ${member.lastName}` : 'Unknown',
                knownId: member?.knownId || '',
                marks: r.marks,
                remarks: r.remarks,
                totalScore,
                totalMax,
                percentage,
                grade,
                passed: percentage >= 33
            };
        })
            .sort((a, b) => b.percentage - a.percentage)
            .map((s, i) => ({ ...s, rank: i + 1 }));
        res.status(constants_1.HTTP_STATUS.OK).json({ exam, ranked });
    }
    catch (error) {
        next(error);
    }
};
exports.getClassRankSheet = getClassRankSheet;
// GET /exams/member/:memberId/report-card — Full year report card
const getMemberReportCard = async (req, res, next) => {
    try {
        const memberId = req.params.memberId;
        const entityId = req.user.entityId.toString();
        const academicYearId = req.query.academicYearId;
        const [allResults, member] = await Promise.all([
            exam_result_service_1.default.getByMember(memberId),
            member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(memberId), entityId: new mongodb_1.ObjectId(entityId) })
        ]);
        if (!member)
            throw new AppError_1.AppError('Member not found', constants_1.HTTP_STATUS.NOT_FOUND);
        // Get all exam headers for these results
        const examIds = [...new Set(allResults.map((r) => r.examId.toString()))];
        let exams = await exam_service_1.default.get({ _id: { $in: examIds.map(id => new mongodb_1.ObjectId(id)) } });
        // Filter by academic year if provided
        if (academicYearId) {
            exams = exams.filter((e) => e.academicYearId?.toString() === academicYearId);
        }
        // Build per-exam breakdown
        const examBreakdowns = exams.map((exam) => {
            const result = allResults.find((r) => r.examId.toString() === exam._id.toString());
            if (!result)
                return { exam, attempted: false };
            const totalScore = result.marks.reduce((sum, m) => sum + m.score, 0);
            const totalMax = result.marks.reduce((sum, m) => sum + m.maxScore, 0);
            const percentage = totalMax > 0 ? Math.round((totalScore / totalMax) * 100) : 0;
            return {
                exam: { _id: exam._id, name: exam.name, startDate: exam.startDate, endDate: exam.endDate },
                attempted: true,
                marks: result.marks,
                remarks: result.remarks,
                totalScore,
                totalMax,
                percentage,
                grade: getGrade(percentage),
                passed: percentage >= 33
            };
        });
        // Cumulative summary across all attempted exams
        const attempted = examBreakdowns.filter((e) => e.attempted);
        const cumTotal = attempted.reduce((sum, e) => sum + e.totalScore, 0);
        const cumMax = attempted.reduce((sum, e) => sum + e.totalMax, 0);
        const cumPct = cumMax > 0 ? Math.round((cumTotal / cumMax) * 100) : 0;
        res.status(constants_1.HTTP_STATUS.OK).json({
            member: {
                _id: member._id,
                name: `${member.firstName} ${member.lastName}`,
                knownId: member.knownId
            },
            examBreakdowns,
            cumulative: {
                totalScore: cumTotal,
                totalMax: cumMax,
                percentage: cumPct,
                grade: getGrade(cumPct),
                passed: cumPct >= 33,
                examsAttempted: attempted.length,
                totalExams: exams.length
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getMemberReportCard = getMemberReportCard;
//# sourceMappingURL=exam.controller.js.map