"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMemberDiaryFeed = exports.updateTracking = exports.createDiaryEntry = exports.getDiaryFeed = void 0;
const diary_service_1 = __importDefault(require("../services/diary.service"));
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const AppError_1 = require("../utils/AppError");
const mongodb_1 = require("mongodb");
const getDiaryFeed = async (req, res) => {
    try {
        const { entityId } = req.user;
        const { classId, academicYearId } = req.query;
        if (!classId)
            return res.status(400).json(new AppError_1.AppError('classId is required', 400));
        const filter = {
            entityId: new mongodb_1.ObjectId(entityId),
            classId: new mongodb_1.ObjectId(classId)
        };
        if (academicYearId)
            filter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const diaries = await diary_service_1.default.getDiariesPopulated(filter);
        const mappedDiaries = diaries.map(doc => {
            const memberMap = new Map(doc.populatedMembers?.map((m) => [m._id.toString(), m]));
            doc.studentTracking = (doc.studentTracking || []).map((t) => ({
                ...t,
                memberId: memberMap.get(t.memberId.toString()) || t.memberId
            }));
            delete doc.populatedMembers;
            return doc;
        });
        res.status(200).json(mappedDiaries);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.getDiaryFeed = getDiaryFeed;
const createDiaryEntry = async (req, res) => {
    try {
        const { entityId, userId } = req.user;
        const { classId, subjectId, academicYearId, type, title, description, dueDate, attachments } = req.body;
        if (!classId || !type || !title || !description) {
            return res.status(400).json(new AppError_1.AppError('Missing required fields', 400));
        }
        let studentTracking = [];
        const feeGroup = await fee_group_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(classId),
            entityId: new mongodb_1.ObjectId(entityId)
        });
        if (feeGroup) {
            let memberIds = [];
            if (academicYearId) {
                const roster = feeGroup.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearId);
                if (roster && roster.members) {
                    memberIds = roster.members.map((id) => id.toString());
                }
            }
            else {
                memberIds = feeGroup.members?.map((id) => id.toString()) || [];
            }
            studentTracking = memberIds.map(id => ({
                memberId: new mongodb_1.ObjectId(id),
                status: 'pending'
            }));
        }
        const newDiary = {
            entityId: new mongodb_1.ObjectId(entityId),
            classId: new mongodb_1.ObjectId(classId),
            type,
            title,
            description,
            attachments: attachments || [],
            createdBy: new mongodb_1.ObjectId(userId),
            studentTracking,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        if (academicYearId)
            newDiary.academicYearId = new mongodb_1.ObjectId(academicYearId);
        if (subjectId)
            newDiary.subjectId = new mongodb_1.ObjectId(subjectId);
        if (dueDate)
            newDiary.dueDate = new Date(dueDate);
        const result = await diary_service_1.default.insert(newDiary);
        const docs = await diary_service_1.default.getDiariesPopulated({ _id: result.insertedId });
        let populated = docs[0];
        if (populated && populated.populatedMembers) {
            const memberMap = new Map(populated.populatedMembers.map((m) => [m._id.toString(), m]));
            populated.studentTracking = (populated.studentTracking || []).map((t) => ({
                ...t,
                memberId: memberMap.get(t.memberId.toString()) || t.memberId
            }));
            delete populated.populatedMembers;
        }
        res.status(201).json(populated);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.createDiaryEntry = createDiaryEntry;
const updateTracking = async (req, res) => {
    try {
        const id = req.params.id;
        const { entityId } = req.user;
        const { updates } = req.body;
        if (!updates || !Array.isArray(updates)) {
            return res.status(400).json(new AppError_1.AppError('Updates array required', 400));
        }
        const diary = await diary_service_1.default.getOne({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) });
        if (!diary)
            return res.status(404).json(new AppError_1.AppError('Diary entry not found', 404));
        const updatesMap = new Map(updates.map((u) => [u.memberId.toString(), u.status]));
        diary.studentTracking.forEach((track) => {
            const memberIdStr = track.memberId.toString();
            if (updatesMap.has(memberIdStr)) {
                track.status = updatesMap.get(memberIdStr);
            }
        });
        await diary_service_1.default.update({ _id: new mongodb_1.ObjectId(id) }, { $set: { studentTracking: diary.studentTracking, updatedAt: new Date() } });
        const docs = await diary_service_1.default.getDiariesPopulated({ _id: new mongodb_1.ObjectId(id) });
        let populated = docs[0];
        if (populated && populated.populatedMembers) {
            const memberMap = new Map(populated.populatedMembers.map((m) => [m._id.toString(), m]));
            populated.studentTracking = (populated.studentTracking || []).map((t) => ({
                ...t,
                memberId: memberMap.get(t.memberId.toString()) || t.memberId
            }));
            delete populated.populatedMembers;
        }
        res.status(200).json(populated);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.updateTracking = updateTracking;
const getMemberDiaryFeed = async (req, res) => {
    try {
        const { entityId } = req.user;
        const memberId = req.params.memberId;
        const { academicYearId } = req.query;
        const filter = {
            entityId: new mongodb_1.ObjectId(entityId),
            'studentTracking.memberId': new mongodb_1.ObjectId(memberId)
        };
        if (academicYearId)
            filter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const diaries = await diary_service_1.default.getDiariesPopulated(filter);
        res.status(200).json(diaries);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.getMemberDiaryFeed = getMemberDiaryFeed;
//# sourceMappingURL=diary.controller.js.map