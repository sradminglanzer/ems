"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateLogo = exports.getBranding = void 0;
const mongodb_1 = require("mongodb");
const db_1 = require("../config/db");
const constants_1 = require("../utils/constants");
/**
 * GET /api/entities/:id/branding
 * Public endpoint — returns only name and logoUrl for pre-auth display (login screen).
 */
const getBranding = async (req, res, next) => {
    try {
        const { id } = req.params;
        let objectId;
        try {
            objectId = new mongodb_1.ObjectId(id);
        }
        catch {
            return res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json({ message: 'Invalid entity ID format' });
        }
        const db = (0, db_1.getDB)();
        const entity = await db.collection('entities').findOne({ _id: objectId }, { projection: { name: 1, logoUrl: 1 } });
        if (!entity) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Entity not found' });
        }
        return res.status(constants_1.HTTP_STATUS.OK).json({
            name: entity.name,
            logoUrl: entity.logoUrl || null
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getBranding = getBranding;
/**
 * PUT /api/entities/logo
 * Authenticated (owner/admin only) — updates the entity's logo URL.
 */
const updateLogo = async (req, res, next) => {
    try {
        const { logoUrl } = req.body;
        if (!logoUrl || typeof logoUrl !== 'string') {
            return res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json({ message: 'logoUrl is required' });
        }
        const entityId = new mongodb_1.ObjectId(req.user.entityId);
        const db = (0, db_1.getDB)();
        const result = await db.collection('entities').updateOne({ _id: entityId }, { $set: { logoUrl, updatedAt: new Date() } });
        if (result.matchedCount === 0) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Entity not found' });
        }
        return res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Logo updated successfully', logoUrl });
    }
    catch (error) {
        next(error);
    }
};
exports.updateLogo = updateLogo;
//# sourceMappingURL=entity.controller.js.map