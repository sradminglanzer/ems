"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setSequence = exports.createFeePayment = exports.getFeePayments = void 0;
const fee_payment_service_1 = __importDefault(require("../services/fee-payment.service"));
const fee_payment_model_1 = require("../models/fee-payment.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const getFeePayments = async (req, res, next) => {
    try {
        const memberId = req.query.memberId;
        const academicYearId = req.query.academicYearId;
        let payments;
        if (memberId) {
            payments = await fee_payment_service_1.default.getByMember(memberId, req.user.entityId, academicYearId);
        }
        else {
            payments = await fee_payment_service_1.default.getByEntity(req.user.entityId, academicYearId);
        }
        res.status(constants_1.HTTP_STATUS.OK).json(payments);
    }
    catch (error) {
        next(error);
    }
};
exports.getFeePayments = getFeePayments;
const createFeePayment = async (req, res, next) => {
    try {
        if (req.body.payments && Array.isArray(req.body.payments)) {
            const results = [];
            for (let p of req.body.payments) {
                const payment = new fee_payment_model_1.FeePayment({ ...p, entityId: req.user.entityId });
                if (payment.valid) {
                    payment.receiptNo = await fee_payment_service_1.default.getNextSequence(req.user.entityId);
                    const result = await fee_payment_service_1.default.insert(payment);
                    results.push({ ...payment, _id: result.insertedId });
                }
            }
            return res.status(constants_1.HTTP_STATUS.CREATED).json(results);
        }
        const payment = new fee_payment_model_1.FeePayment({ ...req.body, entityId: req.user.entityId });
        if (!payment.valid) {
            throw new AppError_1.AppError('Invalid fee payment data', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        payment.receiptNo = await fee_payment_service_1.default.getNextSequence(req.user.entityId);
        const result = await fee_payment_service_1.default.insert(payment);
        res.status(constants_1.HTTP_STATUS.CREATED).json({ ...payment, _id: result.insertedId });
    }
    catch (error) {
        next(error);
    }
};
exports.createFeePayment = createFeePayment;
const setSequence = async (req, res, next) => {
    try {
        const { nextSequence } = req.body;
        if (nextSequence == null || isNaN(nextSequence)) {
            throw new AppError_1.AppError('Invalid sequence number', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        await fee_payment_service_1.default.setNextSequence(req.user.entityId, Number(nextSequence));
        res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Sequence updated successfully' });
    }
    catch (error) {
        next(error);
    }
};
exports.setSequence = setSequence;
//# sourceMappingURL=fee-payment.controller.js.map