import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
export declare const getMembers: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const getMemberById: (req: AuthRequest, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createMember: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const updateMember: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const deleteMember: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const holdMember: (req: AuthRequest, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const resumeMember: (req: AuthRequest, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=member.controller.d.ts.map