"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSubject = exports.updateSubject = exports.createSubject = exports.getSubjects = void 0;
const subject_service_1 = __importDefault(require("../services/subject.service"));
const AppError_1 = require("../utils/AppError");
const mongodb_1 = require("mongodb");
const getSubjects = async (req, res) => {
    try {
        const { entityId } = req.user;
        const subjects = await subject_service_1.default.get({ entityId: new mongodb_1.ObjectId(entityId) }, { sort: { name: 1 } });
        res.status(200).json(subjects);
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.getSubjects = getSubjects;
const createSubject = async (req, res) => {
    try {
        const { entityId } = req.user;
        const { name, code, assignedClasses } = req.body;
        if (!name) {
            return res.status(400).json(new AppError_1.AppError('Subject name is required', 400));
        }
        const newSubject = {
            entityId: new mongodb_1.ObjectId(entityId),
            name,
            code,
            assignedClasses: (assignedClasses || []).map((id) => new mongodb_1.ObjectId(id)),
            createdAt: new Date(),
            updatedAt: new Date()
        };
        const result = await subject_service_1.default.insert(newSubject);
        res.status(201).json({ ...newSubject, _id: result.insertedId });
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.createSubject = createSubject;
const updateSubject = async (req, res) => {
    try {
        const id = req.params.id;
        const { entityId } = req.user;
        const updatedData = { ...req.body, updatedAt: new Date() };
        if (updatedData._id)
            delete updatedData._id;
        if (updatedData.assignedClasses) {
            updatedData.assignedClasses = updatedData.assignedClasses.map((clId) => new mongodb_1.ObjectId(clId));
        }
        const success = await subject_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) }, { $set: updatedData });
        if (!success)
            return res.status(404).json(new AppError_1.AppError('Subject not found', 404));
        res.status(200).json({ success: true });
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.updateSubject = updateSubject;
const deleteSubject = async (req, res) => {
    try {
        const id = req.params.id;
        const { entityId } = req.user;
        const success = await subject_service_1.default.delete({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(entityId) });
        if (!success)
            return res.status(404).json(new AppError_1.AppError('Subject not found', 404));
        res.status(200).json({ message: 'Subject deleted successfully' });
    }
    catch (error) {
        res.status(500).json(new AppError_1.AppError(error.message, 500));
    }
};
exports.deleteSubject = deleteSubject;
//# sourceMappingURL=subject.controller.js.map