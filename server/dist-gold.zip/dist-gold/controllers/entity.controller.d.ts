import { Request, Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
/**
 * GET /api/entities/:id/branding
 * Public endpoint — returns only name and logoUrl for pre-auth display (login screen).
 */
export declare const getBranding: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
/**
 * PUT /api/entities/logo
 * Authenticated (owner/admin only) — updates the entity's logo URL.
 */
export declare const updateLogo: (req: AuthRequest, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=entity.controller.d.ts.map