"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComprehensiveFinancials = exports.getDashboardReports = exports.getDashboardStats = void 0;
const member_service_1 = __importDefault(require("../services/member.service"));
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const fee_structure_service_1 = __importDefault(require("../services/fee-structure.service"));
const fee_payment_service_1 = __importDefault(require("../services/fee-payment.service"));
const expense_service_1 = __importDefault(require("../services/expense.service"));
const user_service_1 = __importDefault(require("../services/user.service"));
const constants_1 = require("../utils/constants");
const mongodb_1 = require("mongodb");
const db_1 = require("../config/db");
const getDashboardStats = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = req.query.academicYearId;
        if (req.user.role === 'parent') {
            const parentUser = await user_service_1.default.getOne({ _id: new mongodb_1.ObjectId(req.user.userId) });
            let members = await member_service_1.default.getByEntity(entityId);
            if (parentUser && parentUser.contactNumber) {
                members = members.filter(m => m.contact === parentUser.contactNumber || m.altContact === parentUser.contactNumber);
            }
            else {
                members = [];
            }
            // Enrich with payment stats for this academic year
            const feePayments = await fee_payment_service_1.default.getByEntity(entityId, academicYearId);
            const feeGroups = await fee_group_service_1.default.getByEntity(entityId);
            const feeStructures = await fee_structure_service_1.default.getByEntity(entityId);
            const groupTotalFees = {};
            feeGroups.forEach(g => {
                const groupStructures = feeStructures.filter(s => s.feeGroupId && s.feeGroupId.toString() === g._id.toString());
                const totalFee = groupStructures.reduce((sum, s) => sum + s.amount, 0);
                groupTotalFees[g._id.toString()] = totalFee;
            });
            const childrenWithStats = members.map(m => {
                const mId = m._id.toString();
                let group;
                if (academicYearId) {
                    group = feeGroups.find(g => {
                        const roster = g.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearId);
                        return roster && roster.members && roster.members.some((id) => id.toString() === mId);
                    });
                }
                else {
                    group = feeGroups.find(g => {
                        return g.yearlyRosters?.some((r) => r.members && r.members.some((id) => id.toString() === mId));
                    });
                }
                let totalFee = 0;
                let groupName = 'Unassigned';
                if (group) {
                    totalFee = groupTotalFees[group._id.toString()] || 0;
                    groupName = group.name;
                }
                if (m.addonFeeIds && m.addonFeeIds.length > 0) {
                    const addonAmount = feeStructures
                        .filter(s => m.addonFeeIds.some((id) => id.toString() === s._id.toString()))
                        .reduce((sum, s) => sum + s.amount, 0);
                    totalFee += addonAmount;
                }
                const memberPayments = feePayments.filter(p => p.memberId.toString() === mId);
                const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0);
                let nextPaymentDate = null;
                const paymentsByStructure = {};
                memberPayments.forEach(p => {
                    const structId = p.feeStructureId ? p.feeStructureId.toString() : 'general';
                    if (!paymentsByStructure[structId])
                        paymentsByStructure[structId] = [];
                    paymentsByStructure[structId].push(p);
                });
                const nextDates = [];
                for (const structId in paymentsByStructure) {
                    const structPayments = paymentsByStructure[structId] || [];
                    const sortedStructPayments = structPayments.sort((a, b) => new Date(b.paymentDate || 0).getTime() - new Date(a.paymentDate || 0).getTime());
                    const latest = sortedStructPayments[0];
                    if (latest && latest.nextPaymentDate) {
                        nextDates.push(new Date(latest.nextPaymentDate));
                    }
                }
                if (nextDates.length > 0) {
                    // Find earliest upcoming date
                    nextPaymentDate = nextDates.sort((a, b) => a.getTime() - b.getTime())[0];
                }
                return {
                    ...m,
                    groupName,
                    totalFee,
                    totalPaid,
                    pendingAmount: totalFee - totalPaid,
                    nextPaymentDate
                };
            });
            return res.status(constants_1.HTTP_STATUS.OK).json({ isParent: true, children: childrenWithStats, totalMembers: members.length });
        }
        const [members, feeGroups, feeStructures, feePayments] = await Promise.all([
            member_service_1.default.getByEntity(entityId),
            fee_group_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId, academicYearId)
        ]);
        const groupTotalFees = {};
        feeGroups.forEach(g => {
            const groupStructures = feeStructures.filter(s => s.feeGroupId && s.feeGroupId.toString() === g._id.toString());
            const totalFee = groupStructures.reduce((sum, s) => sum + s.amount, 0);
            groupTotalFees[g._id.toString()] = totalFee;
        });
        let systemTotalFees = 0;
        let systemTotalPendingDeficits = 0;
        const expiringMembers = [];
        const today = new Date();
        const nextWeek = new Date();
        nextWeek.setDate(today.getDate() + 7);
        members.forEach(m => {
            const mId = m._id.toString();
            // Skip members on hold — they intentionally stopped paying and should not appear as overdue/due-soon
            if (m.status === 'on_hold')
                return;
            const memberPayments = feePayments.filter(p => p.memberId.toString() === mId);
            // ── Build payment-by-structure map (used for both deficit and expiry) ──
            const paymentsByStructure = {};
            memberPayments.forEach(p => {
                const structId = p.feeStructureId ? p.feeStructureId.toString() : 'general';
                if (!paymentsByStructure[structId])
                    paymentsByStructure[structId] = [];
                paymentsByStructure[structId].push(p);
            });
            // ── Find this member's latest nextPaymentDate across all structures ──
            let latestNextDate = null;
            for (const structId in paymentsByStructure) {
                const sorted = paymentsByStructure[structId]?.sort((a, b) => new Date(b.paymentDate || 0).getTime() - new Date(a.paymentDate || 0).getTime()) || [];
                const latest = sorted[0];
                if (latest?.nextPaymentDate) {
                    const d = new Date(latest.nextPaymentDate);
                    if (!latestNextDate || d > latestNextDate)
                        latestNextDate = d;
                }
            }
            // ── GYM MODE: pending deficit = plan amount if member's renewal is overdue ──
            const isGymMode = !academicYearId && feeGroups.length === 0;
            if (isGymMode) {
                if (latestNextDate && latestNextDate < today) {
                    // Member is overdue — add their subscribed plan amounts
                    if (m.addonFeeIds && m.addonFeeIds.length > 0) {
                        const overduePlanAmount = feeStructures
                            .filter(s => m.addonFeeIds.some((id) => id.toString() === s._id.toString()))
                            .reduce((sum, s) => sum + s.amount, 0);
                        systemTotalPendingDeficits += overduePlanAmount;
                    }
                }
            }
            else {
                // ── SCHOOL MODE: deficit = total annual fee – total paid ──
                let group;
                if (academicYearId) {
                    group = feeGroups.find(g => {
                        const roster = g.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearId);
                        return roster && roster.members && roster.members.some((id) => id.toString() === mId);
                    });
                }
                else {
                    group = feeGroups.find(g => {
                        return (g.members && g.members.some((id) => id.toString() === mId)) ||
                            (g.yearlyRosters?.some((r) => r.members && r.members.some((id) => id.toString() === mId)));
                    });
                }
                let memberTotalFee = 0;
                if (group)
                    memberTotalFee += (groupTotalFees[group._id.toString()] || 0);
                if (m.addonFeeIds && m.addonFeeIds.length > 0) {
                    const addonAmount = feeStructures
                        .filter(s => m.addonFeeIds.some((id) => id.toString() === s._id.toString()))
                        .reduce((sum, s) => sum + s.amount, 0);
                    memberTotalFee += addonAmount;
                }
                systemTotalFees += memberTotalFee;
                const memberTotalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0);
                const individualDeficit = memberTotalFee - memberTotalPaid;
                if (individualDeficit > 0)
                    systemTotalPendingDeficits += individualDeficit;
            }
            // ── Expiring / overdue window ──
            // Overdue: any member whose renewal is past (no lower bound — could be months ago)
            // Upcoming: renewals due within next 7 days
            if (latestNextDate) {
                const daysDiff = (latestNextDate.getTime() - today.getTime()) / (1000 * 3600 * 24);
                const isOverdue = daysDiff < 0;
                const isExpiringSoon = daysDiff >= 0 && daysDiff <= 7;
                if (isOverdue || isExpiringSoon) {
                    if (!expiringMembers.some(em => em._id === m._id)) {
                        expiringMembers.push({
                            _id: m._id,
                            firstName: m.firstName,
                            lastName: m.lastName,
                            knownId: m.knownId,
                            contact: m.contact,
                            nextPaymentDate: latestNextDate,
                            isOverdue
                        });
                    }
                }
            }
        });
        // Sort expiring members by date ascending
        expiringMembers.sort((a, b) => new Date(a.nextPaymentDate).getTime() - new Date(b.nextPaymentDate).getTime());
        const systemTotalPaid = feePayments.reduce((sum, p) => sum + p.amount, 0);
        const todayDate = new Date();
        const pad = (n) => n < 10 ? '0' + n : n;
        const todayStr = `${todayDate.getFullYear()}-${pad(todayDate.getMonth() + 1)}-${pad(todayDate.getDate())}`;
        const thisMonthStr = `${todayDate.getFullYear()}-${pad(todayDate.getMonth() + 1)}`;
        const lastMonthDate = new Date(todayDate.getFullYear(), todayDate.getMonth() - 1, 1);
        const lastMonthStr = `${lastMonthDate.getFullYear()}-${pad(lastMonthDate.getMonth() + 1)}`;
        const collectionToday = feePayments.filter(p => {
            const d = new Date(p.paymentDate || p.createdAt || todayDate);
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` === todayStr;
        }).reduce((sum, p) => sum + p.amount, 0);
        const collectionThisMonth = feePayments.filter(p => {
            const d = new Date(p.paymentDate || p.createdAt || todayDate);
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}` === thisMonthStr;
        }).reduce((sum, p) => sum + p.amount, 0);
        const collectionLastMonth = feePayments.filter(p => {
            const d = new Date(p.paymentDate || p.createdAt || todayDate);
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}` === lastMonthStr;
        }).reduce((sum, p) => sum + p.amount, 0);
        const stats = {
            totalMembers: members.length,
            totalFeeGroups: feeGroups.length,
            totalFeeStructures: feeStructures.length,
            totalPendingAmount: systemTotalPendingDeficits,
            totalCollectedAmount: systemTotalPaid,
            collectionToday,
            collectionThisMonth,
            collectionLastMonth,
            expiringMembers
        };
        res.status(constants_1.HTTP_STATUS.OK).json(stats);
    }
    catch (error) {
        next(error);
    }
};
exports.getDashboardStats = getDashboardStats;
const getDashboardReports = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = req.query.academicYearId;
        const [members, feeStructures, feePayments] = await Promise.all([
            member_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId, academicYearId)
        ]);
        // 1. Enriched Payment History
        const paymentHistory = feePayments.map(p => {
            const member = members.find(m => m._id.toString() === p.memberId.toString());
            const structure = feeStructures.find(s => s._id.toString() === p.feeStructureId?.toString());
            return {
                _id: p._id,
                amount: p.amount,
                paymentDate: p.paymentDate || p.createdAt,
                notes: p.notes,
                memberName: member ? `${member.firstName} ${member.lastName}` : 'Deleted Member',
                memberId: p.memberId,
                structureName: structure ? structure.name : 'General Fee'
            };
        }).sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
        // 2. Enrollment Growth (Last 6 months)
        const enrollmentGrowth = {};
        const today = new Date();
        const pad = (n) => n < 10 ? '0' + n : n;
        for (let i = 5; i >= 0; i--) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const monthStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; // YYYY-MM in Local Time
            enrollmentGrowth[monthStr] = 0;
        }
        members.forEach(m => {
            if (m.createdAt) {
                const createdDate = new Date(m.createdAt);
                const monthStr = `${createdDate.getFullYear()}-${pad(createdDate.getMonth() + 1)}`;
                if (enrollmentGrowth[monthStr] !== undefined) {
                    enrollmentGrowth[monthStr]++;
                }
            }
            else {
                // If no createdAt, assume current month (legacy data)
                const currentMonthStr = `${today.getFullYear()}-${pad(today.getMonth() + 1)}`;
                if (enrollmentGrowth[currentMonthStr] !== undefined) {
                    enrollmentGrowth[currentMonthStr]++;
                }
            }
        });
        // 3. Current Month Revenue vs Last Month Revenue
        const currentMonthStr = `${today.getFullYear()}-${pad(today.getMonth() + 1)}`;
        const lastMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const lastMonthStr = `${lastMonthDate.getFullYear()}-${pad(lastMonthDate.getMonth() + 1)}`;
        const currentMonthRevenue = paymentHistory
            .filter(p => {
            const d = new Date(p.paymentDate);
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}` === currentMonthStr;
        })
            .reduce((sum, p) => sum + p.amount, 0);
        const lastMonthRevenue = paymentHistory
            .filter(p => {
            const d = new Date(p.paymentDate);
            return `${d.getFullYear()}-${pad(d.getMonth() + 1)}` === lastMonthStr;
        })
            .reduce((sum, p) => sum + p.amount, 0);
        res.status(constants_1.HTTP_STATUS.OK).json({
            paymentHistory,
            enrollmentGrowth,
            revenueComparison: {
                currentMonth: currentMonthRevenue,
                lastMonth: lastMonthRevenue,
                currentMonthLabel: currentMonthDateLabel(today),
                lastMonthLabel: currentMonthDateLabel(lastMonthDate)
            }
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getDashboardReports = getDashboardReports;
function currentMonthDateLabel(date) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[date.getMonth()]} ${date.getFullYear()}`;
}
const getComprehensiveFinancials = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = req.query.academicYearId;
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        const dateFilter = {};
        const expenseDateFilter = {};
        if (startDate && endDate) {
            dateFilter.paymentDate = { $gte: new Date(startDate), $lte: new Date(endDate) };
            expenseDateFilter.expenseDate = { $gte: new Date(startDate), $lte: new Date(endDate) };
        }
        const expenseFilter = { entityId: new mongodb_1.ObjectId(entityId), ...expenseDateFilter };
        if (academicYearId)
            expenseFilter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const [members, feeGroups, feeStructures, feePayments, expenses, entity] = await Promise.all([
            member_service_1.default.getByEntity(entityId),
            fee_group_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId, academicYearId, dateFilter),
            expense_service_1.default.get(expenseFilter),
            (0, db_1.getDB)().collection('entities').findOne({ _id: new mongodb_1.ObjectId(entityId) })
        ]);
        // === GYM MODE: no fee_groups exist — use fee_structures directly as plans ===
        // === SCHOOL MODE: fee_groups exist — existing group-based logic ===
        const isGymMode = !academicYearId && feeGroups.length === 0;
        const groupTotalFees = {};
        const classWiseData = {};
        if (isGymMode) {
            // Each fee_structure is its own "plan" in gym mode
            feeStructures.forEach((s) => {
                const sId = s._id.toString();
                classWiseData[sId] = { groupName: s.name, collected: 0, pending: 0, memberCount: 0 };
                groupTotalFees[sId] = s.amount;
            });
        }
        else {
            // School mode: build from fee_groups
            feeGroups.forEach((g) => {
                const groupStructures = feeStructures.filter((s) => s.feeGroupId && s.feeGroupId.toString() === g._id.toString());
                const totalFee = groupStructures.reduce((sum, s) => sum + s.amount, 0);
                groupTotalFees[g._id.toString()] = totalFee;
                classWiseData[g._id.toString()] = { groupName: g.name, collected: 0, pending: 0, memberCount: 0 };
            });
        }
        classWiseData['unassigned'] = { groupName: 'Unassigned', collected: 0, pending: 0, memberCount: 0 };
        members.forEach((m) => {
            const mId = m._id.toString();
            const memberPayments = feePayments.filter((p) => p.memberId.toString() === mId);
            const memberTotalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0);
            if (isGymMode) {
                // Gym mode: addonFeeIds[] holds the plan (fee_structure) IDs the member is subscribed to
                const memberPlanIds = (m.addonFeeIds || [])
                    .map((id) => id.toString())
                    .filter((id) => !!classWiseData[id]);
                if (memberPlanIds.length === 0) {
                    // No matching plans — count as unassigned
                    const unassigned = classWiseData['unassigned'];
                    if (unassigned)
                        unassigned.memberCount++;
                    return;
                }
                // Total expected fee across all plans this member is in
                const totalExpected = memberPlanIds.reduce((sum, sId) => sum + (groupTotalFees[sId] || 0), 0);
                memberPlanIds.forEach((sId) => {
                    const planEntry = classWiseData[sId];
                    if (!planEntry)
                        return;
                    const planAmount = groupTotalFees[sId] || 0;
                    planEntry.memberCount++;
                    // Distribute payments proportionally across plans by their amount ratio
                    const ratio = totalExpected > 0 ? planAmount / totalExpected : 0;
                    const allocatedPayment = memberTotalPaid * ratio;
                    planEntry.collected += allocatedPayment;
                    const deficit = planAmount - allocatedPayment;
                    if (deficit > 0)
                        planEntry.pending += deficit;
                });
            }
            else {
                // School mode
                let planId = 'unassigned';
                let memberTotalFee = 0;
                if (academicYearId) {
                    // School mode: match via yearlyRosters
                    const group = feeGroups.find((g) => {
                        const roster = g.yearlyRosters?.find((r) => r.academicYearId.toString() === academicYearId);
                        return roster && roster.members && roster.members.some((id) => id.toString() === mId);
                    });
                    if (group) {
                        planId = group._id.toString();
                        memberTotalFee = groupTotalFees[planId] || 0;
                    }
                }
                else {
                    // School mode (no academic year): match via feeGroupId or members[]
                    let group;
                    if (m.feeGroupId) {
                        group = feeGroups.find((g) => g._id.toString() === m.feeGroupId.toString());
                    }
                    if (!group) {
                        group = feeGroups.find((g) => (g.members && g.members.some((id) => id.toString() === mId)) ||
                            (g.yearlyRosters?.some((r) => r.members && r.members.some((id) => id.toString() === mId))));
                    }
                    if (group) {
                        planId = group._id.toString();
                        memberTotalFee = groupTotalFees[planId] || 0;
                    }
                }
                // Add addon fees on top of the base plan fee (school mode only)
                if (m.addonFeeIds && m.addonFeeIds.length > 0) {
                    const addonAmount = feeStructures
                        .filter((s) => m.addonFeeIds.some((id) => id.toString() === s._id.toString()))
                        .reduce((sum, s) => sum + s.amount, 0);
                    memberTotalFee += addonAmount;
                }
                const planEntry = classWiseData[planId];
                if (planEntry) {
                    planEntry.memberCount++;
                    planEntry.collected += memberTotalPaid;
                    const deficit = memberTotalFee - memberTotalPaid;
                    if (deficit > 0)
                        planEntry.pending += deficit;
                }
            }
        });
        const totalCollected = feePayments.reduce((sum, p) => sum + p.amount, 0);
        const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
        const expenseByCategory = {};
        expenses.forEach((exp) => {
            if (!expenseByCategory[exp.category])
                expenseByCategory[exp.category] = 0;
            expenseByCategory[exp.category] += exp.amount;
        });
        const netBalance = totalCollected - totalExpenses;
        const entityType = entity?.type || 'gym'; // 'gym' | 'school'
        const groupLabel = entityType === 'school' ? 'Class-wise Collections' : 'Plan-wise Collections';
        res.status(constants_1.HTTP_STATUS.OK).json({
            summary: {
                totalCollected,
                totalExpenses,
                netBalance
            },
            groupLabel,
            entityType,
            classWiseData: Object.values(classWiseData).filter((g) => g.groupName !== 'Unassigned' || g.memberCount > 0),
            expensesByCategory: Object.entries(expenseByCategory).map(([category, amount]) => ({ category, amount })),
            recentExpenses: expenses.sort((a, b) => new Date(b.expenseDate).getTime() - new Date(a.expenseDate).getTime()).slice(0, 10),
            recentPayments: feePayments.sort((a, b) => new Date(b.paymentDate || 0).getTime() - new Date(a.paymentDate || 0).getTime()).slice(0, 10)
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getComprehensiveFinancials = getComprehensiveFinancials;
//# sourceMappingURL=dashboard.controller.js.map