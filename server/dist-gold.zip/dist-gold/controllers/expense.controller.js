"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.confirmRecurring = exports.deleteExpense = exports.updateExpense = exports.createExpense = exports.getCategories = exports.getExpenses = void 0;
const expense_service_1 = __importStar(require("../services/expense.service"));
const expense_model_1 = require("../models/expense.model");
const AppError_1 = require("../utils/AppError");
const mongodb_1 = require("mongodb");
const constants_1 = require("../utils/constants");
const getUser = (req) => req.user;
// GET /api/expenses
// Query: startDate, endDate, category, paymentMethod
const getExpenses = async (req, res, next) => {
    try {
        const { entityId } = getUser(req);
        const { startDate, endDate, category, paymentMethod, year, month } = req.query;
        const opts = {};
        if (startDate)
            opts.startDate = new Date(startDate);
        if (endDate)
            opts.endDate = new Date(endDate);
        if (category)
            opts.category = category;
        if (paymentMethod)
            opts.paymentMethod = paymentMethod;
        const [expenses, summary] = await Promise.all([
            expense_service_1.default.getFilteredExpenses(String(entityId), opts),
            year && month
                ? expense_service_1.default.getMonthlySummary(String(entityId), Number(year), Number(month))
                : Promise.resolve([])
        ]);
        res.status(constants_1.HTTP_STATUS.OK).json({ expenses, summary });
    }
    catch (error) {
        next(error);
    }
};
exports.getExpenses = getExpenses;
// GET /api/expenses/categories
const getCategories = async (_req, res, next) => {
    try {
        res.status(constants_1.HTTP_STATUS.OK).json(expense_model_1.EXPENSE_CATEGORIES);
    }
    catch (error) {
        next(error);
    }
};
exports.getCategories = getCategories;
// POST /api/expenses
const createExpense = async (req, res, next) => {
    try {
        const { entityId, userId } = getUser(req);
        const { title, category, amount, expenseDate, paymentMethod, vendor, notes, receiptUrl, isRecurring, recurringFrequency } = req.body;
        if (!title || !category || !amount) {
            return res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json(new AppError_1.AppError('Title, Category and Amount are required', 400));
        }
        const dateOfExpense = expenseDate ? new Date(expenseDate) : new Date();
        // Compute first next recurring date
        let recurringNextDate;
        if (isRecurring && recurringFrequency) {
            recurringNextDate = (0, expense_service_1.computeNextRecurringDate)(dateOfExpense, recurringFrequency);
        }
        const newExpense = {
            entityId: new mongodb_1.ObjectId(String(entityId)),
            title,
            category,
            amount: Number(amount),
            expenseDate: dateOfExpense,
            paymentMethod: paymentMethod || 'cash',
            vendor: vendor || undefined,
            notes: notes || undefined,
            receiptUrl: receiptUrl || undefined,
            status: 'confirmed',
            isRecurring: Boolean(isRecurring),
            recurringFrequency: isRecurring ? recurringFrequency : undefined,
            recurringNextDate,
            recordedBy: new mongodb_1.ObjectId(String(userId)),
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        const result = await expense_service_1.default.insert(newExpense);
        res.status(constants_1.HTTP_STATUS.CREATED).json({ ...newExpense, _id: result.insertedId });
    }
    catch (error) {
        next(error);
    }
};
exports.createExpense = createExpense;
// PUT /api/expenses/:id
const updateExpense = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { entityId } = getUser(req);
        const updates = { ...req.body, updatedAt: new Date() };
        if (updates.expenseDate)
            updates.expenseDate = new Date(updates.expenseDate);
        if (updates.recurringNextDate)
            updates.recurringNextDate = new Date(updates.recurringNextDate);
        // Prevent overwriting ObjectId fields with strings
        delete updates.entityId;
        delete updates.recordedBy;
        delete updates.recurringParentId;
        const success = await expense_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(String(entityId)) }, { $set: updates });
        if (!success)
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json(new AppError_1.AppError('Expense not found', 404));
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true });
    }
    catch (error) {
        next(error);
    }
};
exports.updateExpense = updateExpense;
// DELETE /api/expenses/:id
const deleteExpense = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { entityId } = getUser(req);
        const success = await expense_service_1.default.delete({
            _id: new mongodb_1.ObjectId(id),
            entityId: new mongodb_1.ObjectId(String(entityId))
        });
        if (!success)
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json(new AppError_1.AppError('Expense not found', 404));
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Expense deleted' });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteExpense = deleteExpense;
// PUT /api/expenses/:id/confirm  — confirm a pending_confirmation recurring draft
const confirmRecurring = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { entityId } = getUser(req);
        const { amount } = req.body; // Admin can adjust amount at confirm time
        const expense = await expense_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(id),
            entityId: new mongodb_1.ObjectId(String(entityId)),
            status: 'pending_confirmation'
        });
        if (!expense) {
            return res.status(constants_1.HTTP_STATUS.NOT_FOUND).json(new AppError_1.AppError('Pending expense not found', 404));
        }
        // Confirm the draft
        await expense_service_1.default.update({ _id: new mongodb_1.ObjectId(id) }, {
            $set: {
                status: 'confirmed',
                amount: amount !== undefined ? Number(amount) : expense.amount,
                updatedAt: new Date()
            }
        });
        // Advance recurringNextDate on the parent expense
        if (expense.recurringParentId && expense.recurringFrequency) {
            const nextDate = (0, expense_service_1.computeNextRecurringDate)(expense.expenseDate, expense.recurringFrequency);
            await expense_service_1.default.update({ _id: expense.recurringParentId }, { $set: { recurringNextDate: nextDate, updatedAt: new Date() } });
        }
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Expense confirmed' });
    }
    catch (error) {
        next(error);
    }
};
exports.confirmRecurring = confirmRecurring;
//# sourceMappingURL=expense.controller.js.map