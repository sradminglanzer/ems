import { Request, Response } from 'express';
export declare const getDiaryFeed: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const createDiaryEntry: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateTracking: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getMemberDiaryFeed: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=diary.controller.d.ts.map