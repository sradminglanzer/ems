"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPresignedUrl = void 0;
const constants_1 = require("../utils/constants");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const uuid_1 = require("uuid");
const getPresignedUrl = async (req, res) => {
    try {
        const { filename, contentType } = req.query;
        if (!filename) {
            res.status(constants_1.HTTP_STATUS.BAD_REQUEST).json({ message: 'filename is required' });
            return;
        }
        const bucketName = process.env.AWS_S3_BUCKET_NAME || 'gym-uploads';
        const region = process.env.AWS_REGION || 'ap-south-1';
        // Ensure credentials are available (or S3Client will throw later)
        const s3Client = new client_s3_1.S3Client({
            region,
        });
        // Generate a tenant-safe unique path
        const ext = filename.split('.').pop();
        const tenantId = req.user?.tenantId || 'global';
        const uploadType = req.query.type === 'logo' ? 'logos' : 'members';
        const objectKey = `${tenantId}/${uploadType}/${Date.now()}-${(0, uuid_1.v4)()}.${ext}`;
        const command = new client_s3_1.PutObjectCommand({
            Bucket: bucketName,
            Key: objectKey,
            ContentType: contentType || 'image/jpeg',
        });
        const uploadUrl = await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn: 3600 }); // 1 hour
        const publicUrl = `https://${bucketName}.s3.${region}.amazonaws.com/${objectKey}`;
        res.status(constants_1.HTTP_STATUS.OK).json({
            uploadUrl,
            publicUrl
        });
    }
    catch (error) {
        console.error('Error generating presigned url:', error);
        res.status(constants_1.HTTP_STATUS.INTERNAL_SERVER_ERROR).json({ message: 'Error generating upload URL', error });
    }
};
exports.getPresignedUrl = getPresignedUrl;
//# sourceMappingURL=upload.controller.js.map