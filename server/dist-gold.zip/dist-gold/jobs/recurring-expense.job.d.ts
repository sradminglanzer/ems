export declare const initRecurringExpenseJob: () => void;
//# sourceMappingURL=recurring-expense.job.d.ts.map