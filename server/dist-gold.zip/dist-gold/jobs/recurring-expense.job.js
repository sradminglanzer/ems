"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initRecurringExpenseJob = void 0;
const node_cron_1 = __importDefault(require("node-cron"));
const expense_service_1 = __importStar(require("../services/expense.service"));
const user_service_1 = __importDefault(require("../services/user.service"));
// Use a native dynamic import via Function to bypass TypeScript converting it to require()
const importExpo = new Function("return import('expo-server-sdk')");
const initRecurringExpenseJob = () => {
    // Run every day at midnight
    node_cron_1.default.schedule('0 0 * * *', async () => {
        console.log('[RecurringExpenseJob] Running...');
        try {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            // Find all confirmed recurring expenses whose next date is today or earlier
            const dueExpenses = await expense_service_1.default.get({
                isRecurring: true,
                status: 'confirmed',
                recurringNextDate: { $lte: today }
            });
            if (!dueExpenses.length) {
                console.log('[RecurringExpenseJob] No recurring expenses due today.');
                return;
            }
            const { Expo } = await importExpo();
            const expo = new Expo();
            for (const exp of dueExpenses) {
                // Create a pending_confirmation draft from the parent
                const draft = {
                    entityId: exp.entityId,
                    title: exp.title,
                    category: exp.category,
                    amount: exp.amount,
                    expenseDate: exp.recurringNextDate || today,
                    paymentMethod: exp.paymentMethod,
                    vendor: exp.vendor,
                    notes: exp.notes,
                    status: 'pending_confirmation',
                    isRecurring: false,
                    recurringFrequency: exp.recurringFrequency,
                    recurringParentId: exp._id,
                    recordedBy: exp.recordedBy,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                };
                await expense_service_1.default.insert(draft);
                // Advance the parent's recurringNextDate
                if (exp.recurringFrequency) {
                    const nextDate = (0, expense_service_1.computeNextRecurringDate)(exp.recurringNextDate || today, exp.recurringFrequency);
                    await expense_service_1.default.update({ _id: exp._id }, { $set: { recurringNextDate: nextDate, updatedAt: new Date() } });
                }
                // Notify the entity owner via push notification
                try {
                    const owner = await user_service_1.default.getOne({
                        entityId: exp.entityId,
                        role: { $in: ['owner'] }
                    });
                    if (owner?.expoPushToken && Expo.isExpoPushToken(owner.expoPushToken)) {
                        await expo.sendPushNotificationsAsync([{
                                to: owner.expoPushToken,
                                sound: 'default',
                                title: '💸 Recurring Expense Due',
                                body: `${exp.title} (${exp.category}) — ₹${exp.amount} is pending confirmation.`,
                                data: { type: 'recurring_expense' }
                            }]);
                    }
                }
                catch (notifErr) {
                    console.error('[RecurringExpenseJob] Push notification failed:', notifErr);
                }
                console.log(`[RecurringExpenseJob] Draft created for: ${exp.title}`);
            }
        }
        catch (error) {
            console.error('[RecurringExpenseJob] Error:', error);
        }
    });
    console.log('[RecurringExpenseJob] Initialized (runs daily at midnight).');
};
exports.initRecurringExpenseJob = initRecurringExpenseJob;
//# sourceMappingURL=recurring-expense.job.js.map