export declare const initExpiryAlertJob: () => void;
//# sourceMappingURL=expiry-alert.job.d.ts.map