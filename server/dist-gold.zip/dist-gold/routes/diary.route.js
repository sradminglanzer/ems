"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const diary_controller_1 = require("../controllers/diary.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authenticateToken);
router.route('/')
    .get(diary_controller_1.getDiaryFeed)
    .post(diary_controller_1.createDiaryEntry);
router.route('/:id/tracking')
    .put(diary_controller_1.updateTracking);
router.route('/member/:memberId')
    .get(diary_controller_1.getMemberDiaryFeed);
exports.default = router;
//# sourceMappingURL=diary.route.js.map