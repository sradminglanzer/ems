"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const subject_controller_1 = require("../controllers/subject.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authenticateToken);
router.route('/')
    .get(subject_controller_1.getSubjects)
    .post(subject_controller_1.createSubject);
router.route('/:id')
    .put(subject_controller_1.updateSubject)
    .delete(subject_controller_1.deleteSubject);
exports.default = router;
//# sourceMappingURL=subject.route.js.map