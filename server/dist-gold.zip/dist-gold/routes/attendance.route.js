"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const attendance_controller_1 = require("../controllers/attendance.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authenticateToken);
router.route('/')
    .get(attendance_controller_1.getAttendance)
    .post(attendance_controller_1.saveAttendance);
router.route('/member/:memberId')
    .get(attendance_controller_1.getMemberAttendance);
exports.default = router;
//# sourceMappingURL=attendance.route.js.map