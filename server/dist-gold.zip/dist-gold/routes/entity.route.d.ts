declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=entity.route.d.ts.map