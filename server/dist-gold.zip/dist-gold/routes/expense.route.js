"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const expense_controller_1 = require("../controllers/expense.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = express_1.default.Router();
router.use(auth_middleware_1.authenticateToken);
router.use((0, auth_middleware_1.requireRole)(['owner', 'admin', 'superadmin']));
router.get('/categories', expense_controller_1.getCategories);
router.route('/')
    .get(expense_controller_1.getExpenses)
    .post(expense_controller_1.createExpense);
router.route('/:id')
    .put(expense_controller_1.updateExpense)
    .delete(expense_controller_1.deleteExpense);
router.put('/:id/confirm', expense_controller_1.confirmRecurring);
exports.default = router;
//# sourceMappingURL=expense.route.js.map