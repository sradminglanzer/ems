declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=diary.route.d.ts.map