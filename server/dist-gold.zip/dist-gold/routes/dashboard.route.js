"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const dashboard_controller_1 = require("../controllers/dashboard.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authenticateToken);
router.get('/stats', dashboard_controller_1.getDashboardStats);
router.get('/reports', dashboard_controller_1.getDashboardReports);
router.get('/comprehensive-financials', dashboard_controller_1.getComprehensiveFinancials);
exports.default = router;
//# sourceMappingURL=dashboard.route.js.map