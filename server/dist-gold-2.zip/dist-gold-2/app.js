"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const AppError_1 = require("./utils/AppError");
const auth_route_1 = __importDefault(require("./routes/auth.route"));
const user_route_1 = __importDefault(require("./routes/user.route"));
const fee_group_route_1 = __importDefault(require("./routes/fee-group.route"));
const exam_route_1 = __importDefault(require("./routes/exam.route"));
const fee_structure_route_1 = __importDefault(require("./routes/fee-structure.route"));
const member_route_1 = __importDefault(require("./routes/member.route"));
const fee_payment_route_1 = __importDefault(require("./routes/fee-payment.route"));
const dashboard_route_1 = __importDefault(require("./routes/dashboard.route"));
const academic_year_route_1 = __importDefault(require("./routes/academic-year.route"));
const upload_route_1 = __importDefault(require("./routes/upload.route"));
const expense_route_1 = __importDefault(require("./routes/expense.route"));
const attendance_route_1 = __importDefault(require("./routes/attendance.route"));
const subject_route_1 = __importDefault(require("./routes/subject.route"));
const diary_route_1 = __importDefault(require("./routes/diary.route"));
const entity_route_1 = __importDefault(require("./routes/entity.route"));
const reports_route_1 = __importDefault(require("./routes/reports.route"));
const entity_settings_route_1 = __importDefault(require("./routes/entity-settings.route"));
const staff_route_1 = __importDefault(require("./routes/staff.route"));
const salary_payment_route_1 = __importDefault(require("./routes/salary-payment.route"));
const parent_route_1 = __importDefault(require("./routes/parent.route"));
const error_middleware_1 = require("./middleware/error.middleware");
const app = (0, express_1.default)();
app.use((0, cors_1.default)());
app.use(express_1.default.json());
// Request Logger Middleware
app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`📡 [${new Date().toISOString()}] ${req.method} ${req.originalUrl} - Status: ${res.statusCode} (${duration}ms)`);
    });
    next();
});
// Basic health check route
app.get('/health', (req, res) => {
    res.json({ status: 'ok', message: 'EMS API is running' });
});
// API Routes
app.use('/api/auth', auth_route_1.default);
app.use('/api/parent', parent_route_1.default);
app.use('/api/users', user_route_1.default);
app.use('/api/fee-groups', fee_group_route_1.default);
app.use('/api/exams', exam_route_1.default);
app.use('/api/fee-structures', fee_structure_route_1.default);
app.use('/api/members', member_route_1.default);
app.use('/api/fee-payments', fee_payment_route_1.default);
app.use('/api/dashboard', dashboard_route_1.default);
app.use('/api/academic-years', academic_year_route_1.default);
app.use('/api/upload', upload_route_1.default);
app.use('/api/expenses', expense_route_1.default);
app.use('/api/attendance', attendance_route_1.default);
app.use('/api/subjects', subject_route_1.default);
app.use('/api/diary', diary_route_1.default);
app.use('/api/entities', entity_route_1.default);
app.use('/api/reports', reports_route_1.default);
app.use('/api/entity-settings', entity_settings_route_1.default);
app.use('/api/staff', staff_route_1.default);
app.use('/api/salary-payments', salary_payment_route_1.default);
// Catch-all route for undefined API endpoints
app.use((req, res, next) => {
    next(new AppError_1.AppError(`Can't find ${req.originalUrl} on this server`, 404));
});
// Global Error Handling Middleware (must be last)
app.use(error_middleware_1.errorHandler);
exports.default = app;
//# sourceMappingURL=app.js.map