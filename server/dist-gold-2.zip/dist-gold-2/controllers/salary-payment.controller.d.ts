import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
export declare const getMonthlyPayroll: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const processSalary: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const getPayslip: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=salary-payment.controller.d.ts.map