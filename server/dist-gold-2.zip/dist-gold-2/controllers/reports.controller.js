"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getExpenseBreakdownReport = exports.getPlansBreakdownReport = exports.getPaymentHistoryReport = exports.getReportSummary = void 0;
const mongodb_1 = require("mongodb");
const member_service_1 = __importDefault(require("../services/member.service"));
const fee_structure_service_1 = __importDefault(require("../services/fee-structure.service"));
const fee_payment_service_1 = __importDefault(require("../services/fee-payment.service"));
const expense_service_1 = __importDefault(require("../services/expense.service"));
const constants_1 = require("../utils/constants");
function parseDateFilter(startDate, endDate) {
    const dateFilter = {};
    const expenseDateFilter = {};
    if (startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        dateFilter.$or = [
            { paymentDate: { $gte: start, $lte: end } },
            { paymentDate: { $gte: startDate, $lte: endDate } },
            { createdAt: { $gte: start, $lte: end } }
        ];
        expenseDateFilter.$or = [
            { expenseDate: { $gte: start, $lte: end } },
            { expenseDate: { $gte: startDate, $lte: endDate } },
            { createdAt: { $gte: start, $lte: end } }
        ];
    }
    return { dateFilter, expenseDateFilter };
}
function sanitizeAcademicYearId(academicYearId, entityId) {
    if (!academicYearId || academicYearId === 'null' || academicYearId === 'undefined' || academicYearId === entityId) {
        return undefined;
    }
    return academicYearId;
}
/** 1. GET /api/reports/summary — Light KPI Card Aggregation */
const getReportSummary = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = sanitizeAcademicYearId(req.query.academicYearId, entityId);
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        const { dateFilter, expenseDateFilter } = parseDateFilter(startDate, endDate);
        const expenseFilter = { entityId: new mongodb_1.ObjectId(entityId), ...expenseDateFilter };
        if (academicYearId)
            expenseFilter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const [feePayments, expenses] = await Promise.all([
            fee_payment_service_1.default.getByEntity(entityId, academicYearId, dateFilter),
            expense_service_1.default.get(expenseFilter)
        ]);
        const collections = feePayments.reduce((sum, p) => sum + p.amount, 0);
        const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
        res.status(constants_1.HTTP_STATUS.OK).json({
            collections,
            expenses: totalExpenses,
            netBalance: collections - totalExpenses
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getReportSummary = getReportSummary;
/** 2. GET /api/reports/payments — Paginated & Searchable Payment History */
const getPaymentHistoryReport = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = sanitizeAcademicYearId(req.query.academicYearId, entityId);
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        const paymentMethod = req.query.paymentMethod;
        const search = (req.query.search || '').trim().toLowerCase();
        const page = Math.max(1, parseInt(req.query.page || '1', 10));
        const limit = Math.max(1, Math.min(200, parseInt(req.query.limit || '50', 10)));
        const { dateFilter } = parseDateFilter(startDate, endDate);
        if (paymentMethod && paymentMethod !== 'all') {
            dateFilter.paymentMethod = paymentMethod;
        }
        const [members, feeStructures, feePayments] = await Promise.all([
            member_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId, academicYearId, dateFilter)
        ]);
        const memberMap = new Map();
        members.forEach((m) => memberMap.set(m._id.toString(), m));
        const structureMap = new Map();
        feeStructures.forEach((s) => structureMap.set(s._id.toString(), s));
        let paymentHistory = feePayments.map((p) => {
            const member = p.memberId ? memberMap.get(p.memberId.toString()) : null;
            const structure = p.feeStructureId ? structureMap.get(p.feeStructureId.toString()) : null;
            const isAddon = structure ? (structure.type === 'FeeStructureAddon' || !structure.feeGroupId) : false;
            return {
                _id: p._id.toString(),
                receiptNo: p.receiptNo || null,
                memberName: member ? `${member.firstName} ${member.lastName}`.trim() : 'Deleted Member',
                memberId: p.memberId ? p.memberId.toString() : '',
                structureName: structure ? structure.name : 'General Fee',
                isAddon,
                amount: p.amount,
                paymentDate: p.paymentDate || p.createdAt,
                nextPaymentDate: p.nextPaymentDate || null,
                paymentMethod: p.paymentMethod || 'cash',
                notes: p.notes || null
            };
        });
        if (search) {
            paymentHistory = paymentHistory.filter(p => p.memberName.toLowerCase().includes(search) ||
                p.structureName.toLowerCase().includes(search) ||
                (p.receiptNo && p.receiptNo.toLowerCase().includes(search)) ||
                (p.notes && p.notes.toLowerCase().includes(search)));
        }
        paymentHistory.sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
        const total = paymentHistory.length;
        const totalPages = Math.ceil(total / limit) || 1;
        const startIndex = (page - 1) * limit;
        const paginatedPayments = paymentHistory.slice(startIndex, startIndex + limit);
        res.status(constants_1.HTTP_STATUS.OK).json({
            payments: paginatedPayments,
            total,
            page,
            totalPages
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getPaymentHistoryReport = getPaymentHistoryReport;
/** 3. GET /api/reports/plans-breakdown — Billing Plans & Addons Breakdown */
const getPlansBreakdownReport = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = sanitizeAcademicYearId(req.query.academicYearId, entityId);
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        const { dateFilter } = parseDateFilter(startDate, endDate);
        const [members, feeStructures, feePayments] = await Promise.all([
            member_service_1.default.getByEntity(entityId),
            fee_structure_service_1.default.getByEntity(entityId),
            fee_payment_service_1.default.getByEntity(entityId, academicYearId, dateFilter)
        ]);
        const structureCollected = new Map();
        feePayments.forEach((p) => {
            if (p.feeStructureId) {
                const sId = p.feeStructureId.toString();
                structureCollected.set(sId, (structureCollected.get(sId) || 0) + p.amount);
            }
        });
        const plans = [];
        const addons = [];
        feeStructures.forEach((s) => {
            const sId = s._id.toString();
            const isAddon = s.type === 'FeeStructureAddon' || (!s.feeGroupId && s.type !== 'FeeStructure');
            const memberCount = members.filter((m) => (m.feeGroupId && m.feeGroupId.toString() === s.feeGroupId?.toString()) ||
                (m.addonFeeIds || []).some((id) => id.toString() === sId)).length;
            const item = {
                id: sId,
                name: s.name,
                frequency: s.frequency || 'monthly',
                amount: s.amount,
                isAddon: !!isAddon,
                memberCount,
                collectedAmount: structureCollected.get(sId) || 0
            };
            if (isAddon) {
                addons.push(item);
            }
            else {
                plans.push(item);
            }
        });
        res.status(constants_1.HTTP_STATUS.OK).json({ plans, addons });
    }
    catch (error) {
        next(error);
    }
};
exports.getPlansBreakdownReport = getPlansBreakdownReport;
/** 4. GET /api/reports/expense-breakdown — Expenses by Category */
const getExpenseBreakdownReport = async (req, res, next) => {
    try {
        const entityId = req.user.entityId.toString();
        const academicYearId = sanitizeAcademicYearId(req.query.academicYearId, entityId);
        const startDate = req.query.startDate;
        const endDate = req.query.endDate;
        const { expenseDateFilter } = parseDateFilter(startDate, endDate);
        const expenseFilter = { entityId: new mongodb_1.ObjectId(entityId), ...expenseDateFilter };
        if (academicYearId)
            expenseFilter.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const expenses = await expense_service_1.default.get(expenseFilter);
        const expenseByCategoryMap = {};
        expenses.forEach((exp) => {
            const cat = exp.category || 'Miscellaneous';
            expenseByCategoryMap[cat] = (expenseByCategoryMap[cat] || 0) + exp.amount;
        });
        const topExpenses = Object.entries(expenseByCategoryMap)
            .map(([category, amount]) => ({ _id: category, total: amount }))
            .sort((a, b) => b.total - a.total);
        res.status(constants_1.HTTP_STATUS.OK).json({ expenses: topExpenses });
    }
    catch (error) {
        next(error);
    }
};
exports.getExpenseBreakdownReport = getExpenseBreakdownReport;
//# sourceMappingURL=reports.controller.js.map