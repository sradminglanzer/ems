import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
/** 1. GET /api/staff — Get all staff with enableLogin status flag */
export declare const getStaff: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 2. POST /api/staff — Create staff and user account if enable_login is true */
export declare const createStaff: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** PUT /api/staff/:id — Update staff profile and HR details */
export declare const updateStaff: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 3. DELETE /api/staff/:id — Delete staff and linked user account */
export declare const deleteStaff: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 4. PATCH /api/staff/:id/toggle-login — Toggle enableLogin in users collection */
export declare const toggleStaffLogin: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=staff.controller.d.ts.map