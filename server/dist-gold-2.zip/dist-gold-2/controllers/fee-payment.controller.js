"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFeePayment = exports.updatePaymentNextDate = exports.setSequence = exports.createFeePayment = exports.getFeePayments = void 0;
const mongodb_1 = require("mongodb");
const fee_payment_service_1 = __importDefault(require("../services/fee-payment.service"));
const member_service_1 = __importDefault(require("../services/member.service"));
const fee_payment_model_1 = require("../models/fee-payment.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const getFeePayments = async (req, res, next) => {
    try {
        const memberId = req.query.memberId;
        const academicYearId = req.query.academicYearId;
        let payments;
        if (memberId) {
            payments = await fee_payment_service_1.default.getByMember(memberId, req.user.entityId, academicYearId);
        }
        else {
            payments = await fee_payment_service_1.default.getByEntity(req.user.entityId, academicYearId);
        }
        res.status(constants_1.HTTP_STATUS.OK).json(payments);
    }
    catch (error) {
        next(error);
    }
};
exports.getFeePayments = getFeePayments;
const createFeePayment = async (req, res, next) => {
    try {
        if (req.body.payments && Array.isArray(req.body.payments)) {
            const results = [];
            const memberFeeStructures = new Map();
            for (let p of req.body.payments) {
                const payment = new fee_payment_model_1.FeePayment({ ...p, entityId: req.user.entityId });
                if (payment.valid) {
                    payment.receiptNo = await fee_payment_service_1.default.getNextSequence(req.user.entityId);
                    const result = await fee_payment_service_1.default.insert(payment);
                    results.push({ ...payment, _id: result.insertedId });
                    if (payment.memberId && payment.feeStructureId) {
                        const mId = payment.memberId.toString();
                        const fId = payment.feeStructureId.toString();
                        if (!memberFeeStructures.has(mId)) {
                            memberFeeStructures.set(mId, []);
                        }
                        memberFeeStructures.get(mId).push(fId);
                    }
                }
            }
            // Sync member's addonFeeIds with paid fee structures so active subscriptions reflect collected add-ons/plans
            for (const [mId, structIds] of memberFeeStructures.entries()) {
                const member = await member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(mId), entityId: new mongodb_1.ObjectId(req.user.entityId.toString()) });
                if (member) {
                    const existingAddonIds = (member.addonFeeIds || []).map((id) => id.toString());
                    const updatedAddonIds = Array.from(new Set([...existingAddonIds, ...structIds])).map(id => new mongodb_1.ObjectId(id));
                    await member_service_1.default.update({ _id: new mongodb_1.ObjectId(mId), entityId: new mongodb_1.ObjectId(req.user.entityId.toString()) }, { $set: { addonFeeIds: updatedAddonIds } });
                }
            }
            return res.status(constants_1.HTTP_STATUS.CREATED).json(results);
        }
        const payment = new fee_payment_model_1.FeePayment({ ...req.body, entityId: req.user.entityId });
        if (!payment.valid) {
            throw new AppError_1.AppError('Invalid fee payment data', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        payment.receiptNo = await fee_payment_service_1.default.getNextSequence(req.user.entityId);
        const result = await fee_payment_service_1.default.insert(payment);
        if (payment.memberId && payment.feeStructureId) {
            const mId = payment.memberId.toString();
            const fId = payment.feeStructureId.toString();
            const member = await member_service_1.default.getOne({ _id: new mongodb_1.ObjectId(mId), entityId: new mongodb_1.ObjectId(req.user.entityId.toString()) });
            if (member) {
                const existingAddonIds = (member.addonFeeIds || []).map((id) => id.toString());
                if (!existingAddonIds.includes(fId)) {
                    const updatedAddonIds = [...existingAddonIds.map(id => new mongodb_1.ObjectId(id)), new mongodb_1.ObjectId(fId)];
                    await member_service_1.default.update({ _id: new mongodb_1.ObjectId(mId), entityId: new mongodb_1.ObjectId(req.user.entityId.toString()) }, { $set: { addonFeeIds: updatedAddonIds } });
                }
            }
        }
        res.status(constants_1.HTTP_STATUS.CREATED).json({ ...payment, _id: result.insertedId });
    }
    catch (error) {
        next(error);
    }
};
exports.createFeePayment = createFeePayment;
const setSequence = async (req, res, next) => {
    try {
        const { nextSequence } = req.body;
        if (nextSequence == null || isNaN(nextSequence)) {
            throw new AppError_1.AppError('Invalid sequence number', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        await fee_payment_service_1.default.setNextSequence(req.user.entityId, Number(nextSequence));
        res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Sequence updated successfully' });
    }
    catch (error) {
        next(error);
    }
};
exports.setSequence = setSequence;
const updatePaymentNextDate = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { nextPaymentDate } = req.body;
        if (!nextPaymentDate) {
            throw new AppError_1.AppError('Next payment date is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const dateObj = new Date(nextPaymentDate);
        if (isNaN(dateObj.getTime())) {
            throw new AppError_1.AppError('Invalid date format', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        await fee_payment_service_1.default.update({ _id: new mongodb_1.ObjectId(id), entityId: new mongodb_1.ObjectId(req.user.entityId.toString()) }, { $set: { nextPaymentDate: dateObj } });
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, nextPaymentDate: dateObj });
    }
    catch (error) {
        next(error);
    }
};
exports.updatePaymentNextDate = updatePaymentNextDate;
const deleteFeePayment = async (req, res, next) => {
    try {
        const id = req.params.id;
        await fee_payment_service_1.default.delete({
            _id: new mongodb_1.ObjectId(id),
            entityId: new mongodb_1.ObjectId(req.user.entityId.toString())
        });
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteFeePayment = deleteFeePayment;
//# sourceMappingURL=fee-payment.controller.js.map