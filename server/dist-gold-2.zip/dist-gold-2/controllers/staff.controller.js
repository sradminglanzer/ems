"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.toggleStaffLogin = exports.deleteStaff = exports.updateStaff = exports.createStaff = exports.getStaff = void 0;
const mongodb_1 = require("mongodb");
const staff_service_1 = __importDefault(require("../services/staff.service"));
const user_service_1 = __importDefault(require("../services/user.service"));
const entity_settings_service_1 = __importDefault(require("../services/entity-settings.service"));
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const staff_model_1 = require("../models/staff.model");
const user_model_1 = require("../models/user.model");
const constants_1 = require("../utils/constants");
const AppError_1 = require("../utils/AppError");
/** 1. GET /api/staff — Get all staff with enableLogin status flag */
const getStaff = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const [staffList, usersList] = await Promise.all([
            staff_service_1.default.getByEntity(entityId),
            user_service_1.default.getUsersByEntity(entityId)
        ]);
        const userMap = new Map();
        usersList.forEach((u) => userMap.set(u.contactNumber, u));
        const result = staffList.map((s) => {
            const linkedUser = userMap.get(s.contactNumber);
            return {
                ...s,
                _id: s._id.toString(),
                enableLogin: linkedUser ? linkedUser.enableLogin !== false : false,
                hasUserAccount: !!linkedUser
            };
        });
        res.status(constants_1.HTTP_STATUS.OK).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.getStaff = getStaff;
/** 2. POST /api/staff — Create staff and user account if enable_login is true */
const createStaff = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const { name, contactNumber, role } = req.body;
        if (!name || !contactNumber || !role) {
            throw new AppError_1.AppError('Name, Contact Number, and Role are required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        // 1. Insert into staff collection with all HR fields
        const staff = new staff_model_1.Staff({ ...req.body, entityId });
        const staffInsertResult = await staff_service_1.default.insert(staff);
        // 2. Check entity-settings for role enable_login flag
        const settings = await entity_settings_service_1.default.getByEntity(entityId);
        const matchedRole = settings.staffRoles.find(r => r.code === role);
        const shouldEnableLogin = matchedRole ? matchedRole.enable_login : (role === 'admin' || role === 'owner');
        // 3. Create user account if enable_login is true
        if (shouldEnableLogin) {
            const existingUser = await user_service_1.default.getOne({
                entityId: new mongodb_1.ObjectId(entityId),
                contactNumber
            });
            if (!existingUser) {
                const user = new user_model_1.User({
                    entityId,
                    name,
                    contactNumber,
                    role,
                    enableLogin: true
                });
                await user_service_1.default.insert(user);
            }
            else {
                await user_service_1.default.update({ _id: existingUser._id }, { $set: { enableLogin: true, role, name } });
            }
        }
        // 4. Sync Class Teacher assignment with FeeGroup
        const insertedId = staffInsertResult.insertedId;
        if (insertedId && req.body.assignedClassTeacherGroupId && mongodb_1.ObjectId.isValid(req.body.assignedClassTeacherGroupId)) {
            await fee_group_service_1.default.update({ _id: new mongodb_1.ObjectId(req.body.assignedClassTeacherGroupId), entityId: new mongodb_1.ObjectId(entityId) }, { $set: { classTeacherId: insertedId } });
        }
        const createdDoc = insertedId ? await staff_service_1.default.getOne({ _id: insertedId }) : null;
        res.status(constants_1.HTTP_STATUS.CREATED).json({
            ...createdDoc,
            _id: insertedId ? insertedId.toString() : '',
            enableLogin: shouldEnableLogin
        });
    }
    catch (error) {
        next(error);
    }
};
exports.createStaff = createStaff;
/** PUT /api/staff/:id — Update staff profile and HR details */
const updateStaff = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const staffId = req.params.id;
        if (!staffId || !mongodb_1.ObjectId.isValid(staffId)) {
            throw new AppError_1.AppError('Valid Staff ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const existing = await staff_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(staffId),
            entityId: new mongodb_1.ObjectId(entityId)
        });
        if (!existing) {
            throw new AppError_1.AppError('Staff member not found', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        const updateData = {
            ...req.body,
            entityId: new mongodb_1.ObjectId(entityId),
            updatedAt: new Date()
        };
        delete updateData._id;
        await staff_service_1.default.update({ _id: new mongodb_1.ObjectId(staffId) }, { $set: updateData });
        // Update user account name/role if exists
        if (req.body.name || req.body.role) {
            await user_service_1.default.update({ entityId: new mongodb_1.ObjectId(entityId), contactNumber: existing.contactNumber }, { $set: { ...(req.body.name && { name: req.body.name }), ...(req.body.role && { role: req.body.role }) } });
        }
        // Sync Class Teacher assignment with FeeGroup
        if (req.body.assignedClassTeacherGroupId !== undefined) {
            if (req.body.assignedClassTeacherGroupId && mongodb_1.ObjectId.isValid(req.body.assignedClassTeacherGroupId)) {
                // Clear old assignments for this staff
                await fee_group_service_1.default.update({ entityId: new mongodb_1.ObjectId(entityId), classTeacherId: new mongodb_1.ObjectId(staffId) }, { $unset: { classTeacherId: 1 } });
                // Set new assignment
                await fee_group_service_1.default.update({ _id: new mongodb_1.ObjectId(req.body.assignedClassTeacherGroupId), entityId: new mongodb_1.ObjectId(entityId) }, { $set: { classTeacherId: new mongodb_1.ObjectId(staffId) } });
            }
            else if (req.body.assignedClassTeacherGroupId === null || req.body.assignedClassTeacherGroupId === '') {
                await fee_group_service_1.default.update({ entityId: new mongodb_1.ObjectId(entityId), classTeacherId: new mongodb_1.ObjectId(staffId) }, { $unset: { classTeacherId: 1 } });
            }
        }
        const updatedStaff = await staff_service_1.default.getOne({ _id: new mongodb_1.ObjectId(staffId) });
        res.status(constants_1.HTTP_STATUS.OK).json({
            ...updatedStaff,
            _id: staffId
        });
    }
    catch (error) {
        next(error);
    }
};
exports.updateStaff = updateStaff;
/** 3. DELETE /api/staff/:id — Delete staff and linked user account */
const deleteStaff = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const staffId = req.params.id;
        if (!staffId || !mongodb_1.ObjectId.isValid(staffId)) {
            throw new AppError_1.AppError('Valid Staff ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const staff = await staff_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(staffId),
            entityId: new mongodb_1.ObjectId(entityId)
        });
        if (!staff) {
            throw new AppError_1.AppError('Staff member not found', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        if (staff.role === 'owner') {
            throw new AppError_1.AppError('Cannot delete the owner account', constants_1.HTTP_STATUS.FORBIDDEN);
        }
        // Delete from staff collection
        await staff_service_1.default.delete({ _id: new mongodb_1.ObjectId(staffId) });
        // Delete linked user account from users collection
        await user_service_1.default.delete({
            entityId: new mongodb_1.ObjectId(entityId),
            contactNumber: staff.contactNumber
        });
        res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Staff member deleted successfully' });
    }
    catch (error) {
        next(error);
    }
};
exports.deleteStaff = deleteStaff;
/** 4. PATCH /api/staff/:id/toggle-login — Toggle enableLogin in users collection */
const toggleStaffLogin = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const staffId = req.params.id;
        if (!staffId || !mongodb_1.ObjectId.isValid(staffId)) {
            throw new AppError_1.AppError('Valid Staff ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const staff = await staff_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(staffId),
            entityId: new mongodb_1.ObjectId(entityId)
        });
        if (!staff) {
            throw new AppError_1.AppError('Staff member not found', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        const existingUser = await user_service_1.default.getOne({
            entityId: new mongodb_1.ObjectId(entityId),
            contactNumber: staff.contactNumber
        });
        let newEnableLoginState = true;
        if (existingUser) {
            newEnableLoginState = !(existingUser.enableLogin !== false);
            await user_service_1.default.update({ _id: existingUser._id }, { $set: { enableLogin: newEnableLoginState } });
        }
        else {
            const user = new user_model_1.User({
                entityId,
                name: staff.name,
                contactNumber: staff.contactNumber,
                role: staff.role,
                enableLogin: true
            });
            await user_service_1.default.insert(user);
        }
        res.status(constants_1.HTTP_STATUS.OK).json({
            message: `Login access ${newEnableLoginState ? 'enabled' : 'disabled'}`,
            enableLogin: newEnableLoginState
        });
    }
    catch (error) {
        next(error);
    }
};
exports.toggleStaffLogin = toggleStaffLogin;
//# sourceMappingURL=staff.controller.js.map