"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFeeStructure = exports.updateFeeStructure = exports.createFeeStructure = exports.getFeeStructures = void 0;
const fee_structure_service_1 = __importDefault(require("../services/fee-structure.service"));
const fee_structure_model_1 = require("../models/fee-structure.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const mongodb_1 = require("mongodb");
const getFeeStructures = async (req, res, next) => {
    try {
        const academicYearId = req.query.academicYearId;
        const structures = await fee_structure_service_1.default.getByEntity(req.user.entityId, academicYearId);
        res.status(constants_1.HTTP_STATUS.OK).json(structures);
    }
    catch (error) {
        next(error);
    }
};
exports.getFeeStructures = getFeeStructures;
const createFeeStructure = async (req, res, next) => {
    try {
        const structure = new fee_structure_model_1.FeeStructure({ ...req.body, entityId: req.user.entityId });
        if (!structure.valid) {
            throw new AppError_1.AppError('Invalid fee structure data.', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await fee_structure_service_1.default.insert(structure);
        res.status(constants_1.HTTP_STATUS.CREATED).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.createFeeStructure = createFeeStructure;
const updateFeeStructure = async (req, res, next) => {
    try {
        const id = req.params.id;
        const entityIdObj = new mongodb_1.ObjectId(req.user.entityId);
        const structureIdObj = new mongodb_1.ObjectId(id);
        const existing = await fee_structure_service_1.default.getOne({ _id: structureIdObj, entityId: entityIdObj });
        if (!existing) {
            throw new AppError_1.AppError('Fee structure not found', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        const { name, amount, frequency, academicYearId, feeGroupId, feeGroupIds, type } = req.body;
        const updateData = {};
        if (name !== undefined)
            updateData.name = name;
        if (amount !== undefined)
            updateData.amount = Number(amount);
        if (frequency !== undefined)
            updateData.frequency = frequency;
        if (type !== undefined)
            updateData.type = type;
        if (academicYearId !== undefined) {
            updateData.academicYearId = academicYearId ? new mongodb_1.ObjectId(academicYearId) : null;
        }
        if (feeGroupId !== undefined) {
            updateData.feeGroupId = feeGroupId ? new mongodb_1.ObjectId(feeGroupId) : null;
        }
        if (feeGroupIds !== undefined) {
            if (Array.isArray(feeGroupIds)) {
                updateData.feeGroupIds = feeGroupIds.map((gId) => new mongodb_1.ObjectId(gId));
            }
            else {
                updateData.feeGroupIds = [];
            }
        }
        updateData.updatedAt = new Date();
        await fee_structure_service_1.default.update({ _id: structureIdObj, entityId: entityIdObj }, { $set: updateData });
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Fee structure updated successfully' });
    }
    catch (error) {
        next(error);
    }
};
exports.updateFeeStructure = updateFeeStructure;
const deleteFeeStructure = async (req, res, next) => {
    try {
        const id = req.params.id;
        const result = await fee_structure_service_1.default.delete({ _id: new mongodb_1.ObjectId(id) });
        if (!result) {
            throw new AppError_1.AppError('Fee structure not found.', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        res.status(constants_1.HTTP_STATUS.NO_CONTENT).send();
    }
    catch (error) {
        next(error);
    }
};
exports.deleteFeeStructure = deleteFeeStructure;
//# sourceMappingURL=fee-structure.controller.js.map