"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPayslip = exports.processSalary = exports.getMonthlyPayroll = void 0;
const mongodb_1 = require("mongodb");
const salary_payment_service_1 = __importDefault(require("../services/salary-payment.service"));
const constants_1 = require("../utils/constants");
const AppError_1 = require("../utils/AppError");
const getMonthlyPayroll = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const cal = new Date();
        const month = req.query.month ? Number(req.query.month) : (cal.getMonth() + 1);
        const year = req.query.year ? Number(req.query.year) : cal.getFullYear();
        const payroll = await salary_payment_service_1.default.getMonthlyPayroll(entityId, month, year);
        res.status(constants_1.HTTP_STATUS.OK).json({
            month,
            year,
            totalStaff: payroll.length,
            paidCount: payroll.filter(p => p.status === 'paid').length,
            pendingCount: payroll.filter(p => p.status === 'pending').length,
            totalDisbursed: payroll.reduce((acc, p) => acc + (p.paymentRecord?.netSalary || 0), 0),
            payroll
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getMonthlyPayroll = getMonthlyPayroll;
const processSalary = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const { staffId, month, year } = req.body;
        if (!staffId || !month || !year) {
            throw new AppError_1.AppError('staffId, month, and year are required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await salary_payment_service_1.default.processSalary(entityId, req.body);
        res.status(constants_1.HTTP_STATUS.CREATED).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.processSalary = processSalary;
const getPayslip = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const paymentId = req.params.id;
        if (!paymentId || !mongodb_1.ObjectId.isValid(paymentId)) {
            throw new AppError_1.AppError('Valid Payment ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const payment = await salary_payment_service_1.default.getOne({
            _id: new mongodb_1.ObjectId(paymentId),
            entityId: new mongodb_1.ObjectId(entityId)
        });
        if (!payment) {
            throw new AppError_1.AppError('Payslip record not found', constants_1.HTTP_STATUS.NOT_FOUND);
        }
        res.status(constants_1.HTTP_STATUS.OK).json(payment);
    }
    catch (error) {
        next(error);
    }
};
exports.getPayslip = getPayslip;
//# sourceMappingURL=salary-payment.controller.js.map