import { Request, Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
/**
 * 1. POST /api/auth/parent-login
 * Authenticates a parent using registered mobile number + 4-digit security PIN.
 * Supports multi-child discovery across classes in the school.
 */
export declare const parentLogin: (req: Request, res: Response, next: NextFunction) => Promise<Response<any, Record<string, any>> | undefined>;
/**
 * 2. POST /api/auth/parent-set-pin
 * Allows a parent to update or set their 4-digit security PIN.
 */
export declare const parentSetPin: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/**
 * 3. GET /api/parent/student/:memberId/dashboard
 * Aggregates complete child profile, attendance, diary, exams, fee dues, and receipts.
 */
export declare const getChildDashboard: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=parent.controller.d.ts.map