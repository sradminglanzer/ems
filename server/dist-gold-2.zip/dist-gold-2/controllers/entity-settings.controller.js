"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateEntitySettings = exports.getEntitySettings = void 0;
const entity_settings_service_1 = __importDefault(require("../services/entity-settings.service"));
const constants_1 = require("../utils/constants");
const AppError_1 = require("../utils/AppError");
const getEntitySettings = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const settings = await entity_settings_service_1.default.getByEntity(entityId);
        res.status(constants_1.HTTP_STATUS.OK).json(settings);
    }
    catch (error) {
        next(error);
    }
};
exports.getEntitySettings = getEntitySettings;
const updateEntitySettings = async (req, res, next) => {
    try {
        if (!req.user?.entityId) {
            throw new AppError_1.AppError('Entity ID is required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const entityId = req.user.entityId.toString();
        const { staffRoles } = req.body;
        await entity_settings_service_1.default.updateByEntity(entityId, staffRoles);
        const updated = await entity_settings_service_1.default.getByEntity(entityId);
        res.status(constants_1.HTTP_STATUS.OK).json(updated);
    }
    catch (error) {
        next(error);
    }
};
exports.updateEntitySettings = updateEntitySettings;
//# sourceMappingURL=entity-settings.controller.js.map