import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
/** 1. GET /api/reports/summary — Light KPI Card Aggregation */
export declare const getReportSummary: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 2. GET /api/reports/payments — Paginated & Searchable Payment History */
export declare const getPaymentHistoryReport: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 3. GET /api/reports/plans-breakdown — Billing Plans & Addons Breakdown */
export declare const getPlansBreakdownReport: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
/** 4. GET /api/reports/expense-breakdown — Expenses by Category */
export declare const getExpenseBreakdownReport: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=reports.controller.d.ts.map