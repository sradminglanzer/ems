"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addMemberToGroup = exports.deleteFeeGroup = exports.updateFeeGroup = exports.createFeeGroup = exports.getFeeGroupDetails = exports.getFeeGroups = void 0;
const fee_group_service_1 = __importDefault(require("../services/fee-group.service"));
const member_service_1 = __importDefault(require("../services/member.service"));
const fee_structure_service_1 = __importDefault(require("../services/fee-structure.service"));
const academic_year_service_1 = __importDefault(require("../services/academic-year.service"));
const fee_group_model_1 = require("../models/fee-group.model");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const mongodb_1 = require("mongodb");
const staff_service_1 = __importDefault(require("../services/staff.service"));
const getFeeGroups = async (req, res, next) => {
    try {
        const entityIdObj = new mongodb_1.ObjectId(req.user.entityId);
        const academicYearId = req.query.academicYearId;
        const [groups, activeMembers, staffMembers] = await Promise.all([
            fee_group_service_1.default.getByEntity(req.user.entityId),
            member_service_1.default.get({ entityId: entityIdObj, status: 'active' }),
            staff_service_1.default.getByEntity(req.user.entityId)
        ]);
        const staffMap = new Map();
        staffMembers.forEach((s) => {
            if (s._id) {
                staffMap.set(s._id.toString(), {
                    _id: s._id.toString(),
                    firstName: s.firstName,
                    lastName: s.lastName,
                    phone: s.phone,
                    role: s.role
                });
            }
        });
        const occupancyMap = new Map();
        activeMembers.forEach((m) => {
            if (m.feeGroupId) {
                if (academicYearId) {
                    if (m.academicYearId && m.academicYearId.toString() === academicYearId) {
                        const key = m.feeGroupId.toString();
                        occupancyMap.set(key, (occupancyMap.get(key) || 0) + 1);
                    }
                }
                else {
                    const key = m.feeGroupId.toString();
                    occupancyMap.set(key, (occupancyMap.get(key) || 0) + 1);
                }
            }
        });
        const enrichedGroups = groups.map((g) => {
            const capacity = g.capacity || 1;
            let occupiedCount = occupancyMap.get(g._id.toString()) || 0;
            if (academicYearId && g.yearlyRosters) {
                const roster = g.yearlyRosters.find((r) => r.academicYearId && r.academicYearId.toString() === academicYearId);
                if (roster && Array.isArray(roster.members) && roster.members.length > 0) {
                    occupiedCount = Math.max(occupiedCount, roster.members.length);
                }
            }
            const vacantCount = Math.max(0, capacity - occupiedCount);
            const classTeacher = g.classTeacherId ? staffMap.get(g.classTeacherId.toString()) || null : null;
            return {
                ...g,
                capacity,
                occupiedCount,
                vacantCount,
                isFull: occupiedCount >= capacity,
                classTeacher
            };
        });
        res.status(constants_1.HTTP_STATUS.OK).json(enrichedGroups);
    }
    catch (error) {
        next(error);
    }
};
exports.getFeeGroups = getFeeGroups;
const getFeeGroupDetails = async (req, res, next) => {
    try {
        const id = req.params.id;
        const academicYearId = req.query.academicYearId;
        const entityIdObj = new mongodb_1.ObjectId(req.user.entityId);
        const groupIdObj = new mongodb_1.ObjectId(id);
        const group = await fee_group_service_1.default.getOne({ _id: groupIdObj, entityId: entityIdObj });
        if (!group)
            throw new AppError_1.AppError('Fee group not found', constants_1.HTTP_STATUS.NOT_FOUND);
        let memberIdObjects = [];
        if (academicYearId && group.yearlyRosters) {
            const roster = group.yearlyRosters.find((r) => r.academicYearId.toString() === academicYearId);
            if (roster && roster.members) {
                memberIdObjects = roster.members.map((mId) => new mongodb_1.ObjectId(mId.toString()));
            }
        }
        else if (!academicYearId && group.members) {
            memberIdObjects = group.members.map((mId) => new mongodb_1.ObjectId(mId.toString()));
        }
        // Parallel fetch using services — no raw DB access
        const [members, feeStructures, academicYears, allGroups] = await Promise.all([
            memberIdObjects.length > 0
                ? member_service_1.default.get({ _id: { $in: memberIdObjects }, entityId: entityIdObj })
                : Promise.resolve([]),
            fee_structure_service_1.default.get({ feeGroupId: groupIdObj, entityId: entityIdObj }),
            academic_year_service_1.default.getByEntity(req.user.entityId),
            fee_group_service_1.default.getByEntity(req.user.entityId)
        ]);
        res.status(constants_1.HTTP_STATUS.OK).json({
            group,
            members,
            feeStructures,
            academicYears,
            allGroups
        });
    }
    catch (error) {
        next(error);
    }
};
exports.getFeeGroupDetails = getFeeGroupDetails;
const createFeeGroup = async (req, res, next) => {
    try {
        const feeGroup = new fee_group_model_1.FeeGroup({ ...req.body, entityId: req.user.entityId });
        if (!feeGroup.valid) {
            throw new AppError_1.AppError('Invalid fee group data', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const result = await fee_group_service_1.default.insert(feeGroup);
        res.status(constants_1.HTTP_STATUS.CREATED).json(result);
    }
    catch (error) {
        next(error);
    }
};
exports.createFeeGroup = createFeeGroup;
const updateFeeGroup = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { ObjectId } = require('mongodb');
        // Prevent modifying entity id
        if (req.body.entityId)
            delete req.body.entityId;
        let updateData = { $set: {} };
        if (req.body.name)
            updateData.$set.name = req.body.name;
        if (req.body.description !== undefined)
            updateData.$set.description = req.body.description;
        if (req.body.capacity != null)
            updateData.$set.capacity = Math.max(1, Number(req.body.capacity));
        if (req.body.classTeacherId !== undefined) {
            updateData.$set.classTeacherId = req.body.classTeacherId ? new ObjectId(req.body.classTeacherId) : null;
        }
        // Extract updateData keys properly to pass directly if only name/description updated
        if (Object.keys(updateData.$set).length === 0) {
            delete updateData.$set;
        }
        // If trying to update members, we must handle it via yearlyRosters
        if (req.body.members && req.body.academicYearId) {
            const academicYearIdStr = req.body.academicYearId;
            const newMembers = Array.isArray(req.body.members)
                ? req.body.members.map((mId) => new ObjectId(mId))
                : [];
            // We need to fetch the document first to properly upsert the roster array
            const group = await fee_group_service_1.default.getOne({ _id: new ObjectId(id), entityId: new ObjectId(req.user.entityId) });
            if (!group)
                throw new AppError_1.AppError('Fee group not found', constants_1.HTTP_STATUS.NOT_FOUND);
            let rosters = group.yearlyRosters || [];
            const rosterIdx = rosters.findIndex((r) => r.academicYearId.toString() === academicYearIdStr);
            if (rosterIdx > -1 && rosters[rosterIdx]) {
                // Update existing roster
                rosters[rosterIdx].members = newMembers;
            }
            else {
                // Add new roster for this year
                rosters.push({
                    academicYearId: new ObjectId(academicYearIdStr),
                    members: newMembers
                });
            }
            if (!updateData.$set) {
                updateData.$set = {};
            }
            updateData.$set.yearlyRosters = rosters;
        }
        else if (req.body.members && !req.body.academicYearId) {
            throw new AppError_1.AppError('academicYearId is required when updating members', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        if (updateData && updateData.$set && Object.keys(updateData.$set).length > 0) {
            await fee_group_service_1.default.update({ _id: new ObjectId(id), entityId: new ObjectId(req.user.entityId) }, updateData);
        }
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true });
    }
    catch (error) {
        next(error);
    }
};
exports.updateFeeGroup = updateFeeGroup;
const deleteFeeGroup = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { ObjectId } = require('mongodb');
        const result = await fee_group_service_1.default.delete({ _id: new ObjectId(id), entityId: new ObjectId(req.user.entityId) });
        if (result) {
            res.status(constants_1.HTTP_STATUS.OK).json({ message: 'Fee group deleted' });
        }
        else {
            res.status(constants_1.HTTP_STATUS.NOT_FOUND).json({ message: 'Fee group not found' });
        }
    }
    catch (error) {
        next(error);
    }
};
exports.deleteFeeGroup = deleteFeeGroup;
const addMemberToGroup = async (req, res, next) => {
    try {
        const id = req.params.id;
        const { memberId, academicYearId } = req.body;
        const { ObjectId } = require('mongodb');
        if (!memberId || !academicYearId) {
            throw new AppError_1.AppError('memberId and academicYearId are required', constants_1.HTTP_STATUS.BAD_REQUEST);
        }
        const group = await fee_group_service_1.default.getOne({ _id: new ObjectId(id), entityId: new ObjectId(req.user.entityId) });
        if (!group)
            throw new AppError_1.AppError('Fee group not found', constants_1.HTTP_STATUS.NOT_FOUND);
        let rosters = group.yearlyRosters || [];
        const rosterIdx = rosters.findIndex((r) => r.academicYearId.toString() === academicYearId.toString());
        const newMemberObjId = new ObjectId(memberId);
        if (rosterIdx > -1) {
            // Check if exists to avoid duplicates
            let currentMembers = rosters[rosterIdx].members || [];
            const exists = currentMembers.some((m) => m.toString() === newMemberObjId.toString());
            if (!exists) {
                currentMembers.push(newMemberObjId);
            }
            rosters[rosterIdx].members = currentMembers;
        }
        else {
            rosters.push({
                academicYearId: new ObjectId(academicYearId),
                members: [newMemberObjId]
            });
        }
        await fee_group_service_1.default.update({ _id: new ObjectId(id), entityId: new ObjectId(req.user.entityId) }, { $set: { yearlyRosters: rosters } });
        res.status(constants_1.HTTP_STATUS.OK).json({ success: true, message: 'Member added to group' });
    }
    catch (error) {
        next(error);
    }
};
exports.addMemberToGroup = addMemberToGroup;
//# sourceMappingURL=fee-group.controller.js.map