import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth.middleware';
export declare const getEntitySettings: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
export declare const updateEntitySettings: (req: AuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=entity-settings.controller.d.ts.map