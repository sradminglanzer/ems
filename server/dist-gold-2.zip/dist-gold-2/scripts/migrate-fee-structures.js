"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongodb_1 = require("mongodb");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/ems';
const client = new mongodb_1.MongoClient(uri);
async function migrate() {
    try {
        await client.connect();
        const db = client.db();
        const membersCol = db.collection('members');
        console.log('🔄 Starting migration: Converting addonFeeIds[0] to feeStructureId...');
        const result = await membersCol.updateMany({
            addonFeeIds: { $exists: true, $not: { $size: 0 } },
            $or: [{ feeStructureId: { $exists: false } }, { feeStructureId: null }]
        }, [
            {
                $set: {
                    feeStructureId: { $arrayElemAt: ['$addonFeeIds', 0] },
                    addonFeeIds: { $slice: ['$addonFeeIds', 1, { $size: '$addonFeeIds' }] }
                }
            }
        ]);
        console.log(`✅ Migration complete!`);
        console.log(`📊 Matched documents: ${result.matchedCount}`);
        console.log(`✏️ Modified documents: ${result.modifiedCount}`);
    }
    catch (err) {
        console.error('❌ Migration failed:', err);
    }
    finally {
        await client.close();
    }
}
migrate();
//# sourceMappingURL=migrate-fee-structures.js.map