export {};
//# sourceMappingURL=migrate-fee-structures.d.ts.map