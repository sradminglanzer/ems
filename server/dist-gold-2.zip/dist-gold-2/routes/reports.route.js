"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const reports_controller_1 = require("../controllers/reports.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authenticateToken);
router.get('/summary', reports_controller_1.getReportSummary);
router.get('/payments', reports_controller_1.getPaymentHistoryReport);
router.get('/plans-breakdown', reports_controller_1.getPlansBreakdownReport);
router.get('/expense-breakdown', reports_controller_1.getExpenseBreakdownReport);
exports.default = router;
//# sourceMappingURL=reports.route.js.map