"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const parent_controller_1 = require("../controllers/parent.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = (0, express_1.Router)();
// GET /api/parent/student/:memberId/dashboard
router.get('/student/:memberId/dashboard', auth_middleware_1.authenticateToken, parent_controller_1.getChildDashboard);
exports.default = router;
//# sourceMappingURL=parent.route.js.map