declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=salary-payment.route.d.ts.map