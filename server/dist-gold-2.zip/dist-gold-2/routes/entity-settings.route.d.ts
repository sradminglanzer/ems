declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=entity-settings.route.d.ts.map