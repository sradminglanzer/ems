declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=parent.route.d.ts.map