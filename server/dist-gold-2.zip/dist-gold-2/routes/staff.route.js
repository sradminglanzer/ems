"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const staff_controller_1 = require("../controllers/staff.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authenticateToken);
router.get('/', staff_controller_1.getStaff);
router.post('/', staff_controller_1.createStaff);
router.put('/:id', staff_controller_1.updateStaff);
router.delete('/:id', staff_controller_1.deleteStaff);
router.patch('/:id/toggle-login', staff_controller_1.toggleStaffLogin);
exports.default = router;
//# sourceMappingURL=staff.route.js.map