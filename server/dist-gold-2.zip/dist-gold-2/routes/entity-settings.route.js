"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const entity_settings_controller_1 = require("../controllers/entity-settings.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authenticateToken);
router.get('/', entity_settings_controller_1.getEntitySettings);
router.put('/', entity_settings_controller_1.updateEntitySettings);
exports.default = router;
//# sourceMappingURL=entity-settings.route.js.map