"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const salary_payment_controller_1 = require("../controllers/salary-payment.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authenticateToken);
router.get('/', salary_payment_controller_1.getMonthlyPayroll);
router.post('/', salary_payment_controller_1.processSalary);
router.get('/:id/payslip', salary_payment_controller_1.getPayslip);
exports.default = router;
//# sourceMappingURL=salary-payment.route.js.map