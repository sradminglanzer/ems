"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntitySettingsService = void 0;
const mongodb_1 = require("mongodb");
const base_service_1 = require("./base.service");
const entity_settings_model_1 = require("../models/entity-settings.model");
const db_1 = require("../config/db");
class EntitySettingsService extends base_service_1.BaseService {
    constructor() {
        super('entity-settings');
    }
    async getByEntity(entityIdStr) {
        const entityIdObj = new mongodb_1.ObjectId(entityIdStr);
        // 1. Fetch Entity document to get entityType and optional tenant customSettings
        const entityDoc = await (0, db_1.getDB)().collection('entities').findOne({ _id: entityIdObj });
        const entityType = entityDoc?.type || 'gym';
        // 2. Fetch Category Master Template from entity-settings collection by entityType
        const templateDoc = await this.getOne({ entityType });
        const resolvedSettings = new entity_settings_model_1.EntitySettings(templateDoc || { entityType }, entityType);
        // 3. If tenant has custom white-label overrides on their entity document, merge them
        if (entityDoc?.customSettings) {
            if (entityDoc.customSettings.labels) {
                resolvedSettings.labels = { ...resolvedSettings.labels, ...entityDoc.customSettings.labels };
            }
            if (Array.isArray(entityDoc.customSettings.staffRoles) && entityDoc.customSettings.staffRoles.length > 0) {
                resolvedSettings.staffRoles = entityDoc.customSettings.staffRoles;
            }
        }
        return resolvedSettings;
    }
    async updateByEntity(entityIdStr, updateData) {
        const entityIdObj = new mongodb_1.ObjectId(entityIdStr);
        const customSettingsData = {};
        if (updateData.staffRoles)
            customSettingsData['customSettings.staffRoles'] = updateData.staffRoles;
        if (updateData.labels)
            customSettingsData['customSettings.labels'] = updateData.labels;
        customSettingsData.updatedAt = new Date();
        // Write custom white-label overrides directly to the tenant's entities document
        const result = await (0, db_1.getDB)().collection('entities').updateOne({ _id: entityIdObj }, { $set: customSettingsData });
        return result.acknowledged;
    }
}
exports.EntitySettingsService = EntitySettingsService;
exports.default = new EntitySettingsService();
//# sourceMappingURL=entity-settings.service.js.map