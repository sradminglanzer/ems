"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
const mongodb_1 = require("mongodb");
class FeePaymentService extends base_service_1.BaseService {
    constructor() {
        super('fee_payments');
    }
    async getByEntity(entityId, academicYearId, customFilter = {}) {
        const query = { entityId: new mongodb_1.ObjectId(entityId), ...customFilter };
        if (academicYearId && academicYearId !== 'null' && academicYearId !== 'undefined' && academicYearId.toString() !== entityId.toString()) {
            query.academicYearId = new mongodb_1.ObjectId(academicYearId);
        }
        return this.get(query);
    }
    async getByMember(memberId, entityId, academicYearId) {
        const query = { memberId: new mongodb_1.ObjectId(memberId), entityId: new mongodb_1.ObjectId(entityId) };
        if (academicYearId) {
            query.academicYearId = new mongodb_1.ObjectId(academicYearId);
        }
        return this.get(query, { sort: { paymentDate: -1 } });
    }
    async getNextSequence(entityId) {
        const { getDB } = require('../config/db');
        const db = getDB();
        const counters = db.collection('counters');
        const result = await counters.findOneAndUpdate({ _id: `receiptNo_${entityId.toString()}` }, { $inc: { seq: 1 } }, { returnDocument: 'after', upsert: true });
        const seqNum = result?.seq || 1;
        const paddedSeq = String(seqNum).padStart(4, '0');
        return `REC-${paddedSeq}`;
    }
    async setNextSequence(entityId, newSeq) {
        const { getDB } = require('../config/db');
        const db = getDB();
        const counters = db.collection('counters');
        await counters.updateOne({ _id: `receiptNo_${entityId.toString()}` }, { $set: { seq: newSeq - 1 } }, { upsert: true });
        return true;
    }
    /**
     * Returns collectionToday, collectionThisMonth, collectionLastMonth
     * using a single $facet aggregation — no payment documents fetched into memory.
     */
    async getCollectionStats(entityId, academicYearId) {
        const collection = this.getCollection();
        const today = new Date();
        const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
        const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const match = { entityId: new mongodb_1.ObjectId(entityId) };
        if (academicYearId)
            match.academicYearId = new mongodb_1.ObjectId(academicYearId);
        const [result] = await collection.aggregate([
            { $match: match },
            {
                $facet: {
                    today: [
                        { $match: { paymentDate: { $gte: todayStart, $lt: todayEnd } } },
                        { $group: { _id: null, total: { $sum: '$amount' } } }
                    ],
                    thisMonth: [
                        { $match: { paymentDate: { $gte: thisMonthStart } } },
                        { $group: { _id: null, total: { $sum: '$amount' } } }
                    ],
                    lastMonth: [
                        { $match: { paymentDate: { $gte: lastMonthStart, $lt: thisMonthStart } } },
                        { $group: { _id: null, total: { $sum: '$amount' } } }
                    ]
                }
            }
        ]).toArray();
        return {
            collectionToday: result?.today?.[0]?.total ?? 0,
            collectionThisMonth: result?.thisMonth?.[0]?.total ?? 0,
            collectionLastMonth: result?.lastMonth?.[0]?.total ?? 0,
        };
    }
}
exports.default = new FeePaymentService();
//# sourceMappingURL=fee-payment.service.js.map