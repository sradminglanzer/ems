import { BaseService } from './base.service';
import { SalaryPayment } from '../models/salary-payment.model';
export declare class SalaryPaymentService extends BaseService<SalaryPayment> {
    constructor();
    getMonthlyPayroll(entityIdStr: string, month: number, year: number): Promise<{
        staffId: string;
        employeeId: string | null;
        staffName: string;
        staffRole: string;
        designation: string | null;
        contactNumber: string;
        monthlySalary: number;
        hra: number;
        allowances: number;
        pfDeduction: number;
        taxDeduction: number;
        status: string;
        paymentRecord: any;
    }[]>;
    processSalary(entityIdStr: string, data: any): Promise<{
        _id: string;
        entityId: string;
        staffId: any;
        expenseId: string;
        staffName: string;
        staffRole: string;
        employeeId?: string;
        designation?: string;
        month: number;
        year: number;
        baseSalary: number;
        hra: number;
        allowances: number;
        pfDeduction: number;
        taxDeduction: number;
        unpaidLeaveDeduction: number;
        deductions: number;
        netSalary: number;
        paymentDate: string;
        paymentMethod: "cash" | "upi" | "cheque" | "bank_transfer";
        status: "paid" | "pending";
        remarks?: string;
        createdAt?: Date;
        updatedAt?: Date;
    }>;
}
declare const _default: SalaryPaymentService;
export default _default;
//# sourceMappingURL=salary-payment.service.d.ts.map