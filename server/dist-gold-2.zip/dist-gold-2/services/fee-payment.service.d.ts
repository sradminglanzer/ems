import { FeePayment } from '../models/fee-payment.model';
import { BaseService } from './base.service';
import { ObjectId } from 'mongodb';
declare class FeePaymentService extends BaseService<FeePayment> {
    constructor();
    getByEntity(entityId: string | ObjectId, academicYearId?: string, customFilter?: any): Promise<import("mongodb").WithId<FeePayment>[]>;
    getByMember(memberId: string | ObjectId, entityId: string | ObjectId, academicYearId?: string): Promise<import("mongodb").WithId<FeePayment>[]>;
    getNextSequence(entityId: string | ObjectId): Promise<string>;
    setNextSequence(entityId: string | ObjectId, newSeq: number): Promise<boolean>;
    /**
     * Returns collectionToday, collectionThisMonth, collectionLastMonth
     * using a single $facet aggregation — no payment documents fetched into memory.
     */
    getCollectionStats(entityId: string, academicYearId?: string): Promise<{
        collectionToday: number;
        collectionThisMonth: number;
        collectionLastMonth: number;
    }>;
}
declare const _default: FeePaymentService;
export default _default;
//# sourceMappingURL=fee-payment.service.d.ts.map