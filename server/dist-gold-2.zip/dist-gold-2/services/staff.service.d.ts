import { BaseService } from './base.service';
import { Staff } from '../models/staff.model';
export declare class StaffService extends BaseService<Staff> {
    constructor();
    getByEntity(entityId: string): Promise<Staff[]>;
}
declare const _default: StaffService;
export default _default;
//# sourceMappingURL=staff.service.d.ts.map