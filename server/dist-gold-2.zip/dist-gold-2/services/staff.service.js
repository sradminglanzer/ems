"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffService = void 0;
const mongodb_1 = require("mongodb");
const base_service_1 = require("./base.service");
const staff_model_1 = require("../models/staff.model");
class StaffService extends base_service_1.BaseService {
    constructor() {
        super('staff');
    }
    async getByEntity(entityId) {
        const docs = await this.get({ entityId: new mongodb_1.ObjectId(entityId) });
        return docs.map(d => new staff_model_1.Staff(d));
    }
}
exports.StaffService = StaffService;
exports.default = new StaffService();
//# sourceMappingURL=staff.service.js.map