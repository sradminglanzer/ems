"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
const mongodb_1 = require("mongodb");
class FeeStructureService extends base_service_1.BaseService {
    constructor() {
        super('fee_structures');
    }
    async getByFeeGroup(feeGroupId) {
        const id = new mongodb_1.ObjectId(feeGroupId);
        return await this.get({
            $or: [
                { feeGroupId: id },
                { feeGroupIds: id }
            ]
        });
    }
    async getByEntity(entityId, academicYearId) {
        const matchStage = { entityId: new mongodb_1.ObjectId(entityId) };
        if (academicYearId) {
            matchStage.$or = [
                { academicYearId: new mongodb_1.ObjectId(academicYearId) },
                { academicYearId: null },
                { academicYearId: { $exists: false } }
            ];
        }
        // Aggregate to include fee_group details for single or multi-class fee heads
        const pipeline = [
            { $match: matchStage },
            {
                $lookup: {
                    from: 'fee_groups',
                    let: { singleId: '$feeGroupId', multiIds: '$feeGroupIds' },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $or: [
                                        { $eq: ['$_id', '$$singleId'] },
                                        { $in: ['$_id', { $ifNull: ['$$multiIds', []] }] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'groupsList'
                }
            },
            {
                $addFields: {
                    groupDetails: { $arrayElemAt: ['$groupsList', 0] },
                    groupNames: {
                        $map: {
                            input: '$groupsList',
                            as: 'g',
                            in: '$$g.name'
                        }
                    }
                }
            }
        ];
        const collection = await this.getCollection();
        return await collection.aggregate(pipeline).toArray();
    }
}
exports.default = new FeeStructureService();
//# sourceMappingURL=fee-structure.service.js.map