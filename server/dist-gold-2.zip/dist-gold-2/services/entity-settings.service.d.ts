import { BaseService } from './base.service';
import { EntitySettings } from '../models/entity-settings.model';
export declare class EntitySettingsService extends BaseService<EntitySettings> {
    constructor();
    getByEntity(entityIdStr: string): Promise<EntitySettings>;
    updateByEntity(entityIdStr: string, updateData: {
        staffRoles?: any[];
        labels?: any;
    }): Promise<boolean>;
}
declare const _default: EntitySettingsService;
export default _default;
//# sourceMappingURL=entity-settings.service.d.ts.map