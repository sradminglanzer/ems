import { Member } from '../models/member.model';
import { BaseService } from './base.service';
declare class MemberService extends BaseService<Member> {
    constructor();
    getByEntity(entityId: string): Promise<Member[]>;
    /**
     * Returns only members who are overdue (latestNextPaymentDate < today),
     * excluding members on hold. Uses an aggregation pipeline with $lookup
     * so only the relevant subset is fetched from the DB.
     */
    getOverdueMembers(entityId: string, today: Date): Promise<any[]>;
    /**
     * Returns members who are overdue or have a renewal due within the next 7 days.
     * Members with no payments (null latestNextDate) are excluded.
     */
    getExpiringMembers(entityId: string): Promise<any[]>;
}
declare const _default: MemberService;
export default _default;
//# sourceMappingURL=member.service.d.ts.map