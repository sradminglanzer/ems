"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const base_service_1 = require("./base.service");
const AppError_1 = require("../utils/AppError");
const constants_1 = require("../utils/constants");
const bcrypt_1 = __importDefault(require("bcrypt"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const academic_year_service_1 = __importDefault(require("./academic-year.service"));
const mongodb_1 = require("mongodb");
const db_1 = require("../config/db");
const JWT_SECRET = process.env.JWT_SECRET || 'ems_secure_jwt_key';
class AuthService extends base_service_1.BaseService {
    constructor() {
        super('users');
    }
    async handleLoginOrSetup(contactNumber, entityId, mpin) {
        let user;
        if (entityId) {
            // === SCHOOL MODE: entityId provided (dedicated white-label app) ===
            let objectId;
            try {
                objectId = new mongodb_1.ObjectId(entityId);
            }
            catch (error) {
                throw new AppError_1.AppError('Invalid Entity ID format', constants_1.HTTP_STATUS.BAD_REQUEST);
            }
            user = await this.getOne({ contactNumber, entityId: objectId });
            if (!user) {
                throw new AppError_1.AppError(constants_1.MESSAGES.ERROR.USER_NOT_FOUND, constants_1.HTTP_STATUS.NOT_FOUND);
            }
        }
        else {
            // === SHARED MODE: no entityId (shared gym app) ===
            // Search across all entities by phone number
            const matches = await this.get({ contactNumber, deleted: { $ne: true } });
            if (matches.length === 0) {
                throw new AppError_1.AppError(constants_1.MESSAGES.ERROR.USER_NOT_FOUND, constants_1.HTTP_STATUS.NOT_FOUND);
            }
            if (matches.length > 1) {
                // Multiple entities found — return a picker list
                const db = (0, db_1.getDB)();
                const entityIds = matches.map(m => m.entityId);
                const entities = await db.collection('entities')
                    .find({ _id: { $in: entityIds } })
                    .project({ name: 1, logoUrl: 1, type: 1 })
                    .toArray();
                return {
                    requiresEntitySelection: true,
                    entities: entities.map(e => ({
                        id: e._id,
                        name: e.name || 'Unknown',
                        logoUrl: e.logoUrl || null,
                        type: e.type || 'gym'
                    }))
                };
            }
            // Exactly one match — proceed
            user = matches[0];
        }
        // Block login if enableLogin === false
        if (user.enableLogin === false) {
            throw new AppError_1.AppError('Login is disabled for this staff account. Please contact your administrator.', constants_1.HTTP_STATUS.FORBIDDEN);
        }
        // Fetch entity details (name, type, logo)
        let entityName = 'EMS Portal';
        let entityType = 'school';
        let entityLogoUrl;
        try {
            const db = (0, db_1.getDB)();
            if (db) {
                const entityCol = db.collection('entities');
                const entityDoc = await entityCol.findOne({ _id: user.entityId });
                if (entityDoc) {
                    if (entityDoc.name)
                        entityName = entityDoc.name;
                    if (entityDoc.type)
                        entityType = entityDoc.type;
                    if (entityDoc.logoUrl)
                        entityLogoUrl = entityDoc.logoUrl;
                }
            }
        }
        catch (e) {
            console.error('Error fetching entity name/type during login', e);
        }
        // Setup Flow — user has no MPIN yet
        if (!user.mpin) {
            if (!mpin) {
                return {
                    requiresSetup: true,
                    message: constants_1.MESSAGES.SUCCESS.MPIN_SETUP_REQUIRED,
                    entity: { id: user.entityId, name: entityName, logoUrl: entityLogoUrl }
                };
            }
            const hashedMpin = await bcrypt_1.default.hash(mpin, 10);
            await this.update({ _id: user._id }, { $set: { mpin: hashedMpin, updatedAt: new Date() } });
            const token = this.generateToken(user);
            const activeYear = await academic_year_service_1.default.getOne({ entityId: user.entityId, isActive: true });
            return {
                message: constants_1.MESSAGES.SUCCESS.MPIN_SETUP_SUCCESS,
                token,
                user: await this.formatUserResponse(user, activeYear, entityName, entityType, entityLogoUrl)
            };
        }
        // Login Flow — user has MPIN
        if (!mpin) {
            return {
                requiresMpin: true,
                message: 'Please provide your MPIN to login',
                entity: { id: user.entityId, name: entityName, logoUrl: entityLogoUrl }
            };
        }
        const isMatch = await bcrypt_1.default.compare(mpin, user.mpin);
        if (!isMatch) {
            throw new AppError_1.AppError(constants_1.MESSAGES.ERROR.INVALID_MPIN, constants_1.HTTP_STATUS.UNAUTHORIZED);
        }
        const token = this.generateToken(user);
        const activeYear = await academic_year_service_1.default.getOne({ entityId: user.entityId, isActive: true });
        return {
            message: constants_1.MESSAGES.SUCCESS.LOGIN_SUCCESS,
            token,
            user: await this.formatUserResponse(user, activeYear, entityName, entityType, entityLogoUrl)
        };
    }
    generateToken(user) {
        return jsonwebtoken_1.default.sign({ userId: user._id, role: user.role, entityId: user.entityId }, JWT_SECRET, { expiresIn: '7d' });
    }
    async formatUserResponse(user, activeYear, entityName, entityType, entityLogoUrl) {
        let labels = null;
        try {
            const entitySettingsService = (await Promise.resolve().then(() => __importStar(require('./entity-settings.service')))).default;
            const settings = await entitySettingsService.getByEntity(user.entityId.toString());
            labels = settings.labels;
        }
        catch (_e) {
            null;
        }
        return {
            id: user._id,
            entityId: user.entityId,
            entityName: entityName,
            entityType: entityType,
            entityLogoUrl: entityLogoUrl,
            name: user.name,
            role: user.role,
            contactNumber: user.contactNumber,
            activeAcademicYearId: activeYear?._id,
            activeAcademicYearName: activeYear?.name,
            labels
        };
    }
}
exports.default = new AuthService();
//# sourceMappingURL=auth.service.js.map