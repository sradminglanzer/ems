"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalaryPaymentService = void 0;
const mongodb_1 = require("mongodb");
const base_service_1 = require("./base.service");
const salary_payment_model_1 = require("../models/salary-payment.model");
const staff_service_1 = __importDefault(require("./staff.service"));
const expense_service_1 = __importDefault(require("./expense.service"));
class SalaryPaymentService extends base_service_1.BaseService {
    constructor() {
        super('salary_payments');
    }
    async getMonthlyPayroll(entityIdStr, month, year) {
        const entityId = new mongodb_1.ObjectId(entityIdStr);
        const [staffList, payments] = await Promise.all([
            staff_service_1.default.getByEntity(entityIdStr),
            this.get({ entityId, month, year })
        ]);
        const paymentMap = new Map();
        payments.forEach(p => paymentMap.set(p.staffId.toString(), p));
        return staffList.map(s => {
            const p = paymentMap.get(s._id.toString());
            return {
                staffId: s._id.toString(),
                employeeId: s.employeeId || null,
                staffName: s.name,
                staffRole: s.role,
                designation: s.designation || null,
                contactNumber: s.contactNumber,
                monthlySalary: s.monthlySalary || 0,
                hra: s.hra || 0,
                allowances: s.allowances || 0,
                pfDeduction: s.pfDeduction || 0,
                taxDeduction: s.taxDeduction || 0,
                status: p ? 'paid' : 'pending',
                paymentRecord: p ? {
                    ...p,
                    _id: p._id.toString(),
                    entityId: p.entityId.toString(),
                    staffId: p.staffId.toString(),
                    expenseId: p.expenseId ? p.expenseId.toString() : null
                } : null
            };
        });
    }
    async processSalary(entityIdStr, data) {
        const entityId = new mongodb_1.ObjectId(entityIdStr);
        const staffId = new mongodb_1.ObjectId(data.staffId);
        const staff = await staff_service_1.default.getOne({ _id: staffId, entityId });
        if (!staff) {
            throw new Error('Staff member not found');
        }
        const baseSalary = Number(data.baseSalary ?? staff.monthlySalary ?? 0);
        const hra = Number(data.hra ?? staff.hra ?? 0);
        const allowances = Number(data.allowances ?? staff.allowances ?? 0);
        const pfDeduction = Number(data.pfDeduction ?? staff.pfDeduction ?? 0);
        const taxDeduction = Number(data.taxDeduction ?? staff.taxDeduction ?? 0);
        const unpaidLeaveDeduction = Number(data.unpaidLeaveDeduction ?? 0);
        const totalDeductions = Number(data.deductions != null ? data.deductions : (pfDeduction + taxDeduction + unpaidLeaveDeduction));
        const netSalary = Math.max(0, (baseSalary + hra + allowances) - totalDeductions);
        const paymentDate = data.paymentDate || new Date().toISOString().split('T')[0];
        const paymentMethod = data.paymentMethod || 'cash';
        const remarks = data.remarks || `Salary payment for ${staff.name}`;
        // 1. Automatically create Expense entry under category "Staff Salaries"
        const expenseDoc = {
            entityId,
            title: `Salary: ${staff.name}`,
            category: 'Staff Salaries',
            amount: netSalary,
            expenseDate: new Date(paymentDate),
            paymentMethod: paymentMethod,
            vendor: staff.name,
            notes: remarks,
            status: 'confirmed',
            isRecurring: false,
            recordedBy: entityId,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        const expenseResult = await expense_service_1.default.insert(expenseDoc);
        // 2. Insert into salary_payments collection
        const salaryPayment = new salary_payment_model_1.SalaryPayment({
            entityId,
            staffId,
            staffName: staff.name,
            staffRole: staff.role,
            employeeId: staff.employeeId,
            designation: staff.designation,
            month: Number(data.month),
            year: Number(data.year),
            baseSalary,
            hra,
            allowances,
            pfDeduction,
            taxDeduction,
            unpaidLeaveDeduction,
            deductions: totalDeductions,
            netSalary,
            paymentDate,
            paymentMethod,
            status: 'paid',
            remarks,
            expenseId: expenseResult.insertedId
        });
        const result = await this.insert(salaryPayment);
        return {
            ...salaryPayment,
            _id: result.insertedId.toString(),
            entityId: entityIdStr,
            staffId: data.staffId,
            expenseId: expenseResult.insertedId.toString()
        };
    }
}
exports.SalaryPaymentService = SalaryPaymentService;
exports.default = new SalaryPaymentService();
//# sourceMappingURL=salary-payment.service.js.map