import { ObjectId } from 'mongodb';
export declare class SalaryPayment {
    _id?: ObjectId;
    entityId: ObjectId;
    staffId: ObjectId;
    staffName: string;
    staffRole: string;
    employeeId?: string;
    designation?: string;
    month: number;
    year: number;
    baseSalary: number;
    hra: number;
    allowances: number;
    pfDeduction: number;
    taxDeduction: number;
    unpaidLeaveDeduction: number;
    deductions: number;
    netSalary: number;
    paymentDate: string;
    paymentMethod: 'cash' | 'upi' | 'cheque' | 'bank_transfer';
    status: 'paid' | 'pending';
    remarks?: string;
    expenseId?: ObjectId;
    createdAt?: Date;
    updatedAt?: Date;
    constructor(data: any);
}
//# sourceMappingURL=salary-payment.model.d.ts.map