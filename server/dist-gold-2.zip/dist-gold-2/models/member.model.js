"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Member = void 0;
const mongodb_1 = require("mongodb");
class Member {
    _id;
    entityId;
    academicYearId;
    // ── Documents & Certificates ───────────────────────────────────────────────
    documents;
    // ── Student Identity ───────────────────────────────────────────────────────
    firstName;
    middleName;
    lastName;
    knownId; // Roll / Student ID
    admissionNo; // Official Permanent Admission / SR No
    rollNo; // Class Roll No
    apaarId; // APAAR / PEN / National Student ID
    aadhaarNo; // 12-digit Student Aadhaar
    dob;
    gender;
    placeOfBirth;
    nationality;
    motherTongue;
    religion;
    casteCategory; // General / OC, OBC, SC, ST, EWS
    subCaste;
    bloodGroup;
    medicalNotes;
    identificationMarks;
    // ── Contact & Family Info ──────────────────────────────────────────────────
    contact; // Primary Contact / WhatsApp
    altContact; // Secondary Contact
    email;
    parentPin; // 4-Digit Security PIN for Parent Portal Login
    // Father Details
    fatherName;
    fatherAadhaar;
    fatherQualification;
    fatherOccupation;
    fatherIncome;
    fatherPhone;
    fatherEmail;
    // Mother Details
    motherName;
    motherAadhaar;
    motherQualification;
    motherOccupation;
    motherIncome;
    motherPhone;
    motherEmail;
    // Guardian Details (if applicable)
    guardianName;
    guardianRelation;
    guardianPhone;
    guardianAddress;
    // ── Address & Emergency ───────────────────────────────────────────────────
    address; // Present Address
    presentAddress;
    permanentAddress;
    city;
    district;
    state;
    pincode;
    emergencyContactName;
    emergencyContactPhone;
    emergencyContactRelation;
    // ── Previous Academic History ─────────────────────────────────────────────
    previousSchoolName;
    previousBoard;
    previousClassPassed;
    tcNumber;
    tcDate;
    previousPercentage;
    // ── Fees & Concessions ────────────────────────────────────────────────────
    feeGroupId; // Class / Section / Room / Batch
    feeStructureId; // Primary Fee Package
    addonFeeIds;
    concessionType; // Sibling, Staff Child, Merit, Custom
    concessionValue; // % or fixed amount
    concessionReason;
    // ── Status & Lifecycle ────────────────────────────────────────────────────
    profilePicUrl;
    joiningDate;
    status;
    holdStartDate;
    holdHistory;
    checkoutDetails;
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityId = new mongodb_1.ObjectId(data.entityId);
        if (data.academicYearId)
            this.academicYearId = typeof data.academicYearId === 'string' ? new mongodb_1.ObjectId(data.academicYearId) : data.academicYearId;
        // Student Identity
        this.firstName = data.firstName || data.first_name || '';
        this.middleName = data.middleName || data.middle_name;
        this.lastName = data.lastName || data.last_name || '';
        this.knownId = data.knownId || data.known_id || data.rollNumber || data.admissionNo || '';
        this.admissionNo = data.admissionNo || data.admission_no;
        this.rollNo = data.rollNo || data.roll_no;
        this.apaarId = data.apaarId || data.apaar_id || data.penNo;
        this.aadhaarNo = data.aadhaarNo || data.aadhaar_no;
        this.dob = data.dob || data.dateOfBirth;
        this.gender = data.gender;
        this.placeOfBirth = data.placeOfBirth || data.place_of_birth;
        this.nationality = data.nationality || 'Indian';
        this.motherTongue = data.motherTongue || data.mother_tongue;
        this.religion = data.religion;
        this.casteCategory = data.casteCategory || data.caste_category || data.category;
        this.subCaste = data.subCaste || data.sub_caste;
        this.bloodGroup = data.bloodGroup || data.blood_group;
        this.medicalNotes = data.medicalNotes || data.medical_notes;
        this.identificationMarks = data.identificationMarks || data.identification_marks;
        // Contacts & Parents
        this.contact = data.contact || data.contactNumber || data.phone || data.fatherPhone;
        this.altContact = data.altContact || data.alt_contact || data.motherPhone;
        this.email = data.email;
        this.parentPin = data.parentPin || data.parent_pin;
        // Father
        this.fatherName = data.fatherName || data.father_name;
        this.fatherAadhaar = data.fatherAadhaar || data.father_aadhaar;
        this.fatherQualification = data.fatherQualification || data.father_qualification;
        this.fatherOccupation = data.fatherOccupation || data.father_occupation;
        this.fatherIncome = data.fatherIncome || data.father_income;
        this.fatherPhone = data.fatherPhone || data.father_phone;
        this.fatherEmail = data.fatherEmail || data.father_email;
        // Mother
        this.motherName = data.motherName || data.mother_name;
        this.motherAadhaar = data.motherAadhaar || data.mother_aadhaar;
        this.motherQualification = data.motherQualification || data.mother_qualification;
        this.motherOccupation = data.motherOccupation || data.mother_occupation;
        this.motherIncome = data.motherIncome || data.mother_income;
        this.motherPhone = data.motherPhone || data.mother_phone;
        this.motherEmail = data.motherEmail || data.mother_email;
        // Guardian
        this.guardianName = data.guardianName || data.guardian_name;
        this.guardianRelation = data.guardianRelation || data.guardian_relation;
        this.guardianPhone = data.guardianPhone || data.guardian_phone;
        this.guardianAddress = data.guardianAddress || data.guardian_address;
        // Addresses
        this.address = data.address || data.presentAddress;
        this.presentAddress = data.presentAddress || data.present_address || data.address;
        this.permanentAddress = data.permanentAddress || data.permanent_address;
        this.city = data.city;
        this.district = data.district;
        this.state = data.state;
        this.pincode = data.pincode;
        this.emergencyContactName = data.emergencyContactName || data.emergency_contact_name;
        this.emergencyContactPhone = data.emergencyContactPhone || data.emergency_contact_phone;
        this.emergencyContactRelation = data.emergencyContactRelation || data.emergency_contact_relation;
        // Previous School
        this.previousSchoolName = data.previousSchoolName || data.previous_school_name;
        this.previousBoard = data.previousBoard || data.previous_board;
        this.previousClassPassed = data.previousClassPassed || data.previous_class_passed;
        this.tcNumber = data.tcNumber || data.tc_number;
        this.tcDate = data.tcDate || data.tc_date;
        this.previousPercentage = data.previousPercentage || data.previous_percentage;
        // Fees & Concessions
        if (data.feeGroupId)
            this.feeGroupId = typeof data.feeGroupId === 'string' ? new mongodb_1.ObjectId(data.feeGroupId) : data.feeGroupId;
        if (data.feeStructureId)
            this.feeStructureId = typeof data.feeStructureId === 'string' ? new mongodb_1.ObjectId(data.feeStructureId) : data.feeStructureId;
        if (Array.isArray(data.addonFeeIds)) {
            this.addonFeeIds = data.addonFeeIds.map((id) => typeof id === 'string' ? new mongodb_1.ObjectId(id) : id);
        }
        this.concessionType = data.concessionType || data.concession_type;
        this.concessionValue = Number(data.concessionValue) || 0;
        this.concessionReason = data.concessionReason || data.concession_reason;
        // Lifecycle & Status
        this.profilePicUrl = data.profilePicUrl;
        if (data.joiningDate)
            this.joiningDate = new Date(data.joiningDate);
        this.status = data.status || 'active';
        if (data.holdStartDate)
            this.holdStartDate = new Date(data.holdStartDate);
        if (Array.isArray(data.holdHistory)) {
            this.holdHistory = data.holdHistory.map((h) => ({
                holdDate: new Date(h.holdDate),
                resumeDate: new Date(h.resumeDate)
            }));
        }
        if (data.checkoutDetails) {
            this.checkoutDetails = {
                checkoutDate: new Date(data.checkoutDetails.checkoutDate || new Date()),
                depositAmount: Number(data.checkoutDetails.depositAmount) || 0,
                pendingDues: Number(data.checkoutDetails.pendingDues) || 0,
                deductions: Number(data.checkoutDetails.deductions) || 0,
                deductionReason: data.checkoutDetails.deductionReason,
                netRefunded: Number(data.checkoutDetails.netRefunded) || 0,
                refundMethod: data.checkoutDetails.refundMethod || 'cash',
                notes: data.checkoutDetails.notes
            };
        }
        if (Array.isArray(data.documents)) {
            this.documents = data.documents.map((d) => ({
                title: d.title || 'Document',
                url: d.url || '',
                docType: d.docType || d.type || 'other',
                uploadedAt: d.uploadedAt ? new Date(d.uploadedAt) : new Date()
            }));
        }
        else {
            this.documents = [];
        }
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
    get valid() {
        return !!(this.firstName && this.entityId);
    }
}
exports.Member = Member;
//# sourceMappingURL=member.model.js.map