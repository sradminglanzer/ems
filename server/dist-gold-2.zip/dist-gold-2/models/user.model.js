"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const mongodb_1 = require("mongodb");
class User {
    _id;
    entityId;
    name;
    contactNumber;
    mpin; // Optional initially as they need to set it up
    expoPushToken;
    role;
    enableLogin;
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = typeof data._id === 'string' ? new mongodb_1.ObjectId(data._id) : data._id;
        this.entityId = typeof data.entityId === 'string' ? new mongodb_1.ObjectId(data.entityId) : data.entityId;
        this.name = data.name;
        this.contactNumber = data.contactNumber;
        this.role = data.role;
        this.mpin = data.mpin || '';
        this.expoPushToken = data.expoPushToken;
        this.enableLogin = data.enableLogin !== undefined ? Boolean(data.enableLogin) : true;
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
    get valid() {
        if (!this.entityId || !this.name || !this.contactNumber || !this.role) {
            return false;
        }
        return true;
    }
}
exports.User = User;
//# sourceMappingURL=user.model.js.map