"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeeStructure = void 0;
const mongodb_1 = require("mongodb");
class FeeStructure {
    _id;
    entityId;
    academicYearId; // Links to a specific academic year session (optional for gym/pg).
    feeGroupId; // Links to a specific class / fee group (legacy/single).
    feeGroupIds; // Links to multiple classes / fee groups.
    amount;
    frequency;
    name; // e.g., "Tuition Fee", "Lab Fee"
    type;
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityId = new mongodb_1.ObjectId(data.entityId);
        if (data.academicYearId)
            this.academicYearId = new mongodb_1.ObjectId(data.academicYearId);
        if (data.feeGroupId)
            this.feeGroupId = new mongodb_1.ObjectId(data.feeGroupId);
        if (Array.isArray(data.feeGroupIds) && data.feeGroupIds.length > 0) {
            this.feeGroupIds = data.feeGroupIds.map((id) => new mongodb_1.ObjectId(id));
        }
        else if (data.feeGroupId) {
            this.feeGroupIds = [new mongodb_1.ObjectId(data.feeGroupId)];
        }
        this.amount = Number(data.amount);
        this.frequency = data.frequency;
        this.name = data.name;
        this.type = data.type || ((data.feeGroupId || (this.feeGroupIds && this.feeGroupIds.length > 0)) ? 'FeeStructure' : 'FeeStructureAddon');
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
    get valid() {
        return !!(this.entityId && this.amount > 0 && this.frequency && this.name && this.type);
    }
}
exports.FeeStructure = FeeStructure;
//# sourceMappingURL=fee-structure.model.js.map