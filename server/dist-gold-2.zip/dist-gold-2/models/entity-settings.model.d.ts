import { ObjectId } from 'mongodb';
export interface StaffRoleSetting {
    label: string;
    code: string;
    enable_login: boolean;
}
export interface EntityLabelsSetting {
    memberSingle: string;
    memberPlural: string;
    groupSingle: string;
    groupPlural: string;
    planSingle: string;
    planPlural: string;
    collectionLabel: string;
    memberIcon: string;
    groupIcon: string;
    isBusinessMode: boolean;
    hasAcademicYears: boolean;
}
export declare const DEFAULT_PG_LABELS: EntityLabelsSetting;
export declare const DEFAULT_GYM_LABELS: EntityLabelsSetting;
export declare const DEFAULT_SCHOOL_LABELS: EntityLabelsSetting;
export declare const DEFAULT_GYM_STAFF_ROLES: StaffRoleSetting[];
export declare const DEFAULT_PG_STAFF_ROLES: StaffRoleSetting[];
export declare const DEFAULT_SCHOOL_STAFF_ROLES: StaffRoleSetting[];
export declare class EntitySettings {
    _id?: ObjectId;
    entityType: string;
    labels: EntityLabelsSetting;
    staffRoles: StaffRoleSetting[];
    createdAt?: Date;
    updatedAt?: Date;
    constructor(data: any, defaultType?: string);
}
//# sourceMappingURL=entity-settings.model.d.ts.map