import { ObjectId } from 'mongodb';
export type FeeStructureType = 'FeeStructure' | 'FeeStructureAddon';
export declare class FeeStructure {
    _id?: ObjectId;
    entityId: ObjectId;
    academicYearId?: ObjectId;
    feeGroupId?: ObjectId;
    feeGroupIds?: ObjectId[];
    amount: number;
    frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'half-yearly' | 'annual' | 'one-time';
    name: string;
    type: FeeStructureType;
    createdAt?: Date;
    updatedAt?: Date;
    constructor(data: any);
    get valid(): boolean;
}
//# sourceMappingURL=fee-structure.model.d.ts.map