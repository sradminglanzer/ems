import { ObjectId } from 'mongodb';
export interface EmergencyContact {
    name?: string | undefined;
    phone?: string | undefined;
    relation?: string | undefined;
}
export interface StaffSubjectAllocation {
    feeGroupId: ObjectId;
    feeGroupName?: string | undefined;
    subjectName: string;
}
export declare class Staff {
    _id?: ObjectId | undefined;
    entityId: ObjectId;
    employeeId?: string | undefined;
    name: string;
    contactNumber: string;
    role: string;
    email?: string | undefined;
    gender?: string | undefined;
    dob?: string | undefined;
    designation?: string | undefined;
    qualifications: string[];
    specializationSubjects: string[];
    experienceYears?: number | undefined;
    panNumber?: string | undefined;
    aadhaarNumber?: string | undefined;
    assignedClassTeacherGroupId?: ObjectId | undefined;
    assignedSubjects: StaffSubjectAllocation[];
    monthlySalary?: number | undefined;
    hra?: number | undefined;
    allowances?: number | undefined;
    pfDeduction?: number | undefined;
    taxDeduction?: number | undefined;
    salaryType: 'monthly' | 'hourly' | 'commission';
    joiningDate?: string | undefined;
    employmentType: 'full-time' | 'part-time' | 'contract';
    status: 'active' | 'inactive' | 'on-leave';
    address?: string | undefined;
    emergencyContact?: EmergencyContact | undefined;
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    constructor(data: any);
    get valid(): boolean;
}
//# sourceMappingURL=staff.model.d.ts.map