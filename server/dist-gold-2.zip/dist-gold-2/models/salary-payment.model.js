"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalaryPayment = void 0;
const mongodb_1 = require("mongodb");
class SalaryPayment {
    _id;
    entityId;
    staffId;
    staffName;
    staffRole;
    employeeId;
    designation;
    month; // 1-12
    year; // e.g. 2026
    // Earnings
    baseSalary;
    hra;
    allowances;
    // Deductions
    pfDeduction;
    taxDeduction;
    unpaidLeaveDeduction;
    deductions;
    // Net
    netSalary;
    paymentDate; // YYYY-MM-DD
    paymentMethod;
    status;
    remarks;
    expenseId;
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityId = new mongodb_1.ObjectId(data.entityId);
        this.staffId = new mongodb_1.ObjectId(data.staffId);
        this.staffName = data.staffName;
        this.staffRole = data.staffRole || 'staff';
        this.employeeId = data.employeeId || undefined;
        this.designation = data.designation || undefined;
        this.month = Number(data.month);
        this.year = Number(data.year);
        this.baseSalary = Number(data.baseSalary || 0);
        this.hra = Number(data.hra || 0);
        this.allowances = Number(data.allowances || 0);
        this.pfDeduction = Number(data.pfDeduction || 0);
        this.taxDeduction = Number(data.taxDeduction || 0);
        this.unpaidLeaveDeduction = Number(data.unpaidLeaveDeduction || 0);
        this.deductions = Number(data.deductions != null ? data.deductions : (this.pfDeduction + this.taxDeduction + this.unpaidLeaveDeduction));
        const totalEarnings = this.baseSalary + this.hra + this.allowances;
        this.netSalary = Math.max(0, totalEarnings - this.deductions);
        this.paymentDate = data.paymentDate || new Date().toISOString().split('T')[0];
        this.paymentMethod = data.paymentMethod || 'cash';
        this.status = data.status || 'paid';
        this.remarks = data.remarks || undefined;
        if (data.expenseId)
            this.expenseId = new mongodb_1.ObjectId(data.expenseId);
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
}
exports.SalaryPayment = SalaryPayment;
//# sourceMappingURL=salary-payment.model.js.map