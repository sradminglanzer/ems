"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Staff = void 0;
const mongodb_1 = require("mongodb");
class Staff {
    _id;
    entityId;
    employeeId;
    name;
    contactNumber;
    role; // 'teacher' | 'admin' | 'accountant' | 'librarian' | 'driver' | 'peon' | 'security' | 'other'
    email;
    gender; // 'male' | 'female' | 'other'
    dob;
    designation;
    qualifications;
    specializationSubjects;
    experienceYears;
    panNumber;
    aadhaarNumber;
    // School Workload Allocations
    assignedClassTeacherGroupId; // If assigned as Class Teacher for a class/section
    assignedSubjects; // Subjects taught across classes
    // Compensation (No bank details required)
    monthlySalary; // Base Salary
    hra;
    allowances;
    pfDeduction;
    taxDeduction;
    salaryType;
    joiningDate;
    employmentType;
    status;
    address;
    emergencyContact;
    createdAt;
    updatedAt;
    constructor(data) {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityId = new mongodb_1.ObjectId(data.entityId);
        if (data.employeeId)
            this.employeeId = data.employeeId;
        this.name = data.name;
        this.contactNumber = data.contactNumber;
        this.role = data.role || 'staff';
        if (data.email)
            this.email = data.email;
        if (data.gender)
            this.gender = data.gender;
        if (data.dob)
            this.dob = data.dob;
        if (data.designation)
            this.designation = data.designation;
        this.qualifications = Array.isArray(data.qualifications) ? data.qualifications : [];
        this.specializationSubjects = Array.isArray(data.specializationSubjects) ? data.specializationSubjects : [];
        if (data.experienceYears != null)
            this.experienceYears = Number(data.experienceYears);
        if (data.panNumber)
            this.panNumber = data.panNumber;
        if (data.aadhaarNumber)
            this.aadhaarNumber = data.aadhaarNumber;
        if (data.assignedClassTeacherGroupId) {
            this.assignedClassTeacherGroupId = new mongodb_1.ObjectId(data.assignedClassTeacherGroupId);
        }
        this.assignedSubjects = Array.isArray(data.assignedSubjects) ? data.assignedSubjects.map((s) => ({
            feeGroupId: new mongodb_1.ObjectId(s.feeGroupId),
            feeGroupName: s.feeGroupName || undefined,
            subjectName: s.subjectName
        })) : [];
        this.monthlySalary = data.monthlySalary != null ? Number(data.monthlySalary) : 0;
        this.hra = data.hra != null ? Number(data.hra) : 0;
        this.allowances = data.allowances != null ? Number(data.allowances) : 0;
        this.pfDeduction = data.pfDeduction != null ? Number(data.pfDeduction) : 0;
        this.taxDeduction = data.taxDeduction != null ? Number(data.taxDeduction) : 0;
        this.salaryType = data.salaryType || 'monthly';
        if (data.joiningDate)
            this.joiningDate = data.joiningDate;
        this.employmentType = data.employmentType || 'full-time';
        this.status = data.status || 'active';
        if (data.address)
            this.address = data.address;
        if (data.emergencyContact)
            this.emergencyContact = data.emergencyContact;
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
    get valid() {
        return !!(this.entityId && this.name && this.contactNumber && this.role);
    }
}
exports.Staff = Staff;
//# sourceMappingURL=staff.model.js.map