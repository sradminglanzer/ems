"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntitySettings = exports.DEFAULT_SCHOOL_STAFF_ROLES = exports.DEFAULT_PG_STAFF_ROLES = exports.DEFAULT_GYM_STAFF_ROLES = exports.DEFAULT_SCHOOL_LABELS = exports.DEFAULT_GYM_LABELS = exports.DEFAULT_PG_LABELS = void 0;
const mongodb_1 = require("mongodb");
exports.DEFAULT_PG_LABELS = {
    memberSingle: 'Tenant',
    memberPlural: 'Tenants',
    groupSingle: 'Room',
    groupPlural: 'Rooms',
    planSingle: 'Rent Plan',
    planPlural: 'Rent Plans',
    collectionLabel: 'Rent Collections',
    memberIcon: '🪪',
    groupIcon: '🛏️',
    isBusinessMode: true,
    hasAcademicYears: false
};
exports.DEFAULT_GYM_LABELS = {
    memberSingle: 'Member',
    memberPlural: 'Members',
    groupSingle: 'Plan',
    groupPlural: 'Plans',
    planSingle: 'Billing Plan',
    planPlural: 'Billing Plans',
    collectionLabel: 'Total Collections',
    memberIcon: '👥',
    groupIcon: '💳',
    isBusinessMode: true,
    hasAcademicYears: false
};
exports.DEFAULT_SCHOOL_LABELS = {
    memberSingle: 'Student',
    memberPlural: 'Students',
    groupSingle: 'Class',
    groupPlural: 'Classes',
    planSingle: 'Fee Structure',
    planPlural: 'Fee Structures',
    collectionLabel: 'Fee Collections',
    memberIcon: '🎒',
    groupIcon: '📚',
    isBusinessMode: false,
    hasAcademicYears: true
};
exports.DEFAULT_GYM_STAFF_ROLES = [
    { label: 'Admin', code: 'admin', enable_login: true },
    { label: 'Staff', code: 'staff', enable_login: false }
];
exports.DEFAULT_PG_STAFF_ROLES = [
    { label: 'Admin', code: 'admin', enable_login: true },
    { label: 'PG Manager', code: 'staff', enable_login: false }
];
exports.DEFAULT_SCHOOL_STAFF_ROLES = [
    { label: 'Admin', code: 'admin', enable_login: true },
    { label: 'Teacher', code: 'teacher', enable_login: true },
    { label: 'Staff', code: 'staff', enable_login: false }
];
class EntitySettings {
    _id;
    entityType;
    labels;
    staffRoles;
    createdAt;
    updatedAt;
    constructor(data, defaultType = 'gym') {
        if (data._id)
            this._id = new mongodb_1.ObjectId(data._id);
        this.entityType = data.entityType || defaultType;
        const typeLower = (this.entityType || 'gym').toLowerCase();
        const defaultLabels = (typeLower === 'pg' || typeLower === 'hostel')
            ? exports.DEFAULT_PG_LABELS
            : (typeLower === 'gym' ? exports.DEFAULT_GYM_LABELS : exports.DEFAULT_SCHOOL_LABELS);
        const defaultRoles = (typeLower === 'pg' || typeLower === 'hostel')
            ? exports.DEFAULT_PG_STAFF_ROLES
            : (typeLower === 'gym' ? exports.DEFAULT_GYM_STAFF_ROLES : exports.DEFAULT_SCHOOL_STAFF_ROLES);
        this.labels = data.labels ? { ...defaultLabels, ...data.labels } : defaultLabels;
        this.staffRoles = Array.isArray(data.staffRoles) && data.staffRoles.length > 0
            ? data.staffRoles
            : defaultRoles;
        this.createdAt = data.createdAt || new Date();
        this.updatedAt = data.updatedAt || new Date();
    }
}
exports.EntitySettings = EntitySettings;
//# sourceMappingURL=entity-settings.model.js.map