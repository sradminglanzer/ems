import { ObjectId } from 'mongodb';
export interface YearlyRoster {
    academicYearId: ObjectId;
    members: ObjectId[];
}
export declare class FeeGroup {
    _id?: ObjectId | undefined;
    entityId: ObjectId;
    name: string;
    description?: string | undefined;
    capacity: number;
    classTeacherId?: ObjectId | undefined;
    yearlyRosters: YearlyRoster[];
    members: ObjectId[];
    createdAt?: Date | undefined;
    updatedAt?: Date | undefined;
    constructor(data: any);
    get valid(): boolean;
}
//# sourceMappingURL=fee-group.model.d.ts.map